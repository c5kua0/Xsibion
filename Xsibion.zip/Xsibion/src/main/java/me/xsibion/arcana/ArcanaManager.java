package me.xsibion.arcana;

import me.xsibion.Xsibion;
import org.bukkit.Material;
import org.bukkit.entity.Player;

/**
 * Reads configured Arcana reward amounts and applies them to a player's balance.
 */
public class ArcanaManager {

    private final Xsibion plugin;

    public ArcanaManager(Xsibion plugin) {
        this.plugin = plugin;
    }

    public double getHostileMobKillReward() {
        return plugin.getConfig().getDouble("arcana.rewards.hostile-mob-kill", 2.0);
    }

    public double getPassiveMobKillReward() {
        return plugin.getConfig().getDouble("arcana.rewards.passive-mob-kill", 0.5);
    }

    public double getVillagerTradeReward() {
        return plugin.getConfig().getDouble("arcana.rewards.villager-trade", 3.0);
    }

    public double getAdvancementReward() {
        return plugin.getConfig().getDouble("arcana.rewards.advancement", 15.0);
    }

    public double getBossKillReward() {
        return plugin.getConfig().getDouble("arcana.rewards.boss-kill", 100.0);
    }

    public double getQuestReward() {
        return plugin.getConfig().getDouble("arcana.rewards.quest", 25.0);
    }

    public double getOreReward(Material material) {
        return plugin.getConfig().getDouble("arcana.rewards.ore-mining." + material.name(), 0.0);
    }

    public boolean isOreRewarded(Material material) {
        return plugin.getConfig().contains("arcana.rewards.ore-mining." + material.name());
    }

    public void grant(Player player, double amount) {
        if (amount <= 0) {
            return;
        }
        plugin.getPlayerDataManager().get(player).addArcana(amount);
    }
}
