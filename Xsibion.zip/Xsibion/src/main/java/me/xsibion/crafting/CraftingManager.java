package me.xsibion.crafting;

import me.xsibion.Xsibion;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Loads and matches custom Xsibion crafting recipes (config: crafting.recipes).
 */
public class CraftingManager {

    private final Xsibion plugin;
    private final List<CraftingRecipe> recipes = new ArrayList<>();

    public CraftingManager(Xsibion plugin) {
        this.plugin = plugin;
        loadRecipes();
    }

    public void loadRecipes() {
        recipes.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("crafting.recipes");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection recipeSection = section.getConfigurationSection(key);
            if (recipeSection != null && recipeSection.getString("result-id") != null) {
                try {
                    recipes.add(new CraftingRecipe(key, recipeSection));
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().warning("Skipping invalid crafting recipe '" + key + "': " + ex.getMessage());
                }
            }
        }
    }

    public List<CraftingRecipe> getRecipes() {
        return recipes;
    }

    /**
     * Summarises a set of grid ItemStacks into a Material -> total count map,
     * ignoring empty slots.
     */
    public Map<Material, Integer> summarize(ItemStack[] gridItems) {
        Map<Material, Integer> summary = new EnumMap<>(Material.class);
        for (ItemStack stack : gridItems) {
            if (stack == null || stack.getType() == Material.AIR) {
                continue;
            }
            summary.merge(stack.getType(), stack.getAmount(), Integer::sum);
        }
        return summary;
    }

    /**
     * Finds the single recipe whose material requirements exactly match the
     * given grid contents, or null if none match.
     */
    public CraftingRecipe findMatch(ItemStack[] gridItems) {
        Map<Material, Integer> summary = summarize(gridItems);
        if (summary.isEmpty()) {
            return null;
        }
        for (CraftingRecipe recipe : recipes) {
            if (recipe.matchesGrid(summary)) {
                return recipe;
            }
        }
        return null;
    }
}
