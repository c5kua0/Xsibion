package me.xsibion.crafting;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * One custom Xsibion crafting recipe: consumes materials from the 3x3 grid
 * plus an Arcana cost, and either upgrades a skill or a magic item by one level.
 */
public class CraftingRecipe {

    public enum ResultType {
        SKILL,
        ITEM
    }

    private final String recipeId;
    private final ResultType resultType;
    private final String resultId;
    private final int resultLevel;
    private final int requiresCurrentLevel;
    private final double arcanaCost;
    private final Map<Material, Integer> materials = new LinkedHashMap<>();

    public CraftingRecipe(String recipeId, ConfigurationSection section) {
        this.recipeId = recipeId;
        this.resultType = ResultType.valueOf(section.getString("result-type", "SKILL").toUpperCase());
        this.resultId = section.getString("result-id");
        this.resultLevel = section.getInt("result-level");
        this.requiresCurrentLevel = section.getInt("requires-current-level");
        this.arcanaCost = section.getDouble("arcana-cost", 0);

        if (section.isConfigurationSection("materials")) {
            for (String matKey : section.getConfigurationSection("materials").getKeys(false)) {
                Material material = Material.matchMaterial(matKey);
                if (material != null) {
                    materials.put(material, section.getInt("materials." + matKey));
                }
            }
        }
    }

    public String getRecipeId() {
        return recipeId;
    }

    public ResultType getResultType() {
        return resultType;
    }

    public String getResultId() {
        return resultId;
    }

    public int getResultLevel() {
        return resultLevel;
    }

    public int getRequiresCurrentLevel() {
        return requiresCurrentLevel;
    }

    public double getArcanaCost() {
        return arcanaCost;
    }

    public Map<Material, Integer> getMaterials() {
        return materials;
    }

    /**
     * Whether the given grid contents (material -> count) match this recipe's
     * required materials exactly - same material types, at least the required count.
     */
    public boolean matchesGrid(Map<Material, Integer> gridContents) {
        if (gridContents.size() != materials.size()) {
            return false;
        }
        for (Map.Entry<Material, Integer> entry : materials.entrySet()) {
            Integer gridAmount = gridContents.get(entry.getKey());
            if (gridAmount == null || gridAmount < entry.getValue()) {
                return false;
            }
        }
        return true;
    }
}
