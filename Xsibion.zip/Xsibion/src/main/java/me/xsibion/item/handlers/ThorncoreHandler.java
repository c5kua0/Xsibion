package me.xsibion.item.handlers;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Thorncore: nature/thorn defensive abilities - reflects a percentage of
 * incoming melee damage back onto the attacker.
 */
public class ThorncoreHandler implements MagicItemHandler, Listener {

    private final Xsibion plugin;

    public ThorncoreHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public MagicItemId getId() {
        return MagicItemId.THORNCORE;
    }

    @Override
    public void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // handled reactively on incoming attacks
    }

    @Override
    public void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamaged(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getMagicItemLevel(MagicItemId.THORNCORE.key());
        if (level <= 0 || !data.isMagicItemEquipped(MagicItemId.THORNCORE.key())) {
            return;
        }
        Entity damagerEntity = event.getDamager();
        if (!(damagerEntity instanceof LivingEntity) || damagerEntity.equals(player)) {
            return;
        }
        LivingEntity attacker = (LivingEntity) damagerEntity;

        MagicItemLevelDefinition levelDef = plugin.getMagicItemManager().getDefinition(MagicItemId.THORNCORE).getLevel(level);
        double percent = levelDef.getDouble("reflect-percent", 10.0);
        double reflected = event.getFinalDamage() * (percent / 100.0);
        if (reflected > 0 && attacker.isValid()) {
            attacker.damage(reflected);
        }
    }
}
