package me.xsibion.item;

/**
 * The 7 Xsibion Magic Items. Each has 3 levels (1 = Early/I, 2 = Mid/II, 3 = Late/III).
 */
public enum MagicItemId {

    WINDCALLER("windcaller"),
    GUARDIAN_SHIELD("guardian_shield"),
    PHOENIX_FEATHER("phoenix_feather"),
    LIFEBLOOM("lifebloom"),
    STORMCORE("stormcore"),
    MOONSTONE("moonstone"),
    THORNCORE("thorncore");

    private final String configKey;

    MagicItemId(String configKey) {
        this.configKey = configKey;
    }

    public String key() {
        return configKey;
    }

    public static MagicItemId fromKey(String key) {
        for (MagicItemId id : values()) {
            if (id.configKey.equalsIgnoreCase(key)) {
                return id;
            }
        }
        return null;
    }
}
