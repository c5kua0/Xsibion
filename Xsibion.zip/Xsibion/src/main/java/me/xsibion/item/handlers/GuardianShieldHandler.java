package me.xsibion.item.handlers;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Guardian Shield: defensive and damage-reduction abilities - flat percentage
 * damage reduction while equipped.
 */
public class GuardianShieldHandler implements MagicItemHandler, Listener {

    private final Xsibion plugin;

    public GuardianShieldHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public MagicItemId getId() {
        return MagicItemId.GUARDIAN_SHIELD;
    }

    @Override
    public void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // handled reactively in the damage listener
    }

    @Override
    public void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getMagicItemLevel(MagicItemId.GUARDIAN_SHIELD.key());
        if (level <= 0 || !data.isMagicItemEquipped(MagicItemId.GUARDIAN_SHIELD.key())) {
            return;
        }
        MagicItemLevelDefinition levelDef = plugin.getMagicItemManager().getDefinition(MagicItemId.GUARDIAN_SHIELD).getLevel(level);
        double percent = levelDef.getDouble("damage-reduction-percent", 0);
        event.setDamage(event.getDamage() * Math.max(0, 1.0 - (percent / 100.0)));
    }
}
