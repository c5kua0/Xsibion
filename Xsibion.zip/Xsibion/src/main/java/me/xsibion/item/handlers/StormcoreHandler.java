package me.xsibion.item.handlers;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Stormcore: lightning/electric abilities - melee hits have a chance to
 * strike a (cosmetic, non-destructive) lightning bolt and deal bonus damage.
 */
public class StormcoreHandler implements MagicItemHandler, Listener {

    private final Xsibion plugin;

    public StormcoreHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public MagicItemId getId() {
        return MagicItemId.STORMCORE;
    }

    @Override
    public void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // handled reactively on melee hit
    }

    @Override
    public void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        Entity damagerEntity = event.getDamager();
        if (!(damagerEntity instanceof Player)) {
            return;
        }
        if (!(event.getEntity() instanceof LivingEntity)) {
            return;
        }
        Player player = (Player) damagerEntity;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getMagicItemLevel(MagicItemId.STORMCORE.key());
        if (level <= 0 || !data.isMagicItemEquipped(MagicItemId.STORMCORE.key())) {
            return;
        }
        if (data.isMagicItemOnCooldown(MagicItemId.STORMCORE.key())) {
            return;
        }

        MagicItemLevelDefinition levelDef = plugin.getMagicItemManager().getDefinition(MagicItemId.STORMCORE).getLevel(level);
        double chance = levelDef.getDouble("proc-chance-percent", 10.0) / 100.0;
        if (ThreadLocalRandom.current().nextDouble() > chance) {
            return;
        }

        double bonusDamage = levelDef.getDouble("bonus-damage", 3.0);
        double cooldown = levelDef.getDouble("cooldown-seconds", 5.0);
        data.setMagicItemCooldown(MagicItemId.STORMCORE.key(), cooldown);

        LivingEntity target = (LivingEntity) event.getEntity();
        target.getWorld().strikeLightningEffect(target.getLocation());
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (target.isValid()) {
                target.damage(bonusDamage, player);
            }
        });
    }
}
