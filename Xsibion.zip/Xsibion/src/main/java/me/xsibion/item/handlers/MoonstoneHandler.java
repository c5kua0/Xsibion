package me.xsibion.item.handlers;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import me.xsibion.util.SpeedEffectCoordinator;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Moonstone: moon and magic-related abilities - permanent Night Vision, plus
 * a bonus movement speed while it is night in the player's world (routed
 * through SpeedEffectCoordinator since Quickstep/Windcaller also grant SPEED).
 */
public class MoonstoneHandler implements MagicItemHandler {

    private final Xsibion plugin;
    private final Map<UUID, BukkitTask> tasks = new ConcurrentHashMap<>();

    public MoonstoneHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public MagicItemId getId() {
        return MagicItemId.MOONSTONE;
    }

    @Override
    public void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false, true));
        SpeedEffectCoordinator.recalculate(plugin, player);

        stop(player.getUniqueId());
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) {
                stop(player.getUniqueId());
                return;
            }
            PlayerData current = plugin.getPlayerDataManager().get(player);
            if (!current.isMagicItemEquipped(MagicItemId.MOONSTONE.key())) {
                stop(player.getUniqueId());
                return;
            }
            SpeedEffectCoordinator.recalculate(plugin, player);
        }, 100L, 100L);
        tasks.put(player.getUniqueId(), task);
    }

    @Override
    public void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        stop(player.getUniqueId());
        player.removePotionEffect(PotionEffectType.NIGHT_VISION);
        SpeedEffectCoordinator.recalculate(plugin, player);
    }

    private void stop(UUID uuid) {
        BukkitTask task = tasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }
    }
}
