package me.xsibion.item.handlers;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Lifebloom: regeneration and healing abilities - passive Regeneration while equipped.
 */
public class LifebloomHandler implements MagicItemHandler {

    private final Xsibion plugin;

    public LifebloomHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public MagicItemId getId() {
        return MagicItemId.LIFEBLOOM;
    }

    @Override
    public void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        int amplifier = levelDef.getInt("regeneration-amplifier", 0);
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, amplifier, false, false, true));
    }

    @Override
    public void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        player.removePotionEffect(PotionEffectType.REGENERATION);
    }
}
