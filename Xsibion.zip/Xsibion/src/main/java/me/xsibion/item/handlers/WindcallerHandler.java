package me.xsibion.item.handlers;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import me.xsibion.util.SpeedEffectCoordinator;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Windcaller: movement and wind-related passive abilities - grants Speed
 * (via SpeedEffectCoordinator, since Quickstep/Moonstone can also grant it)
 * and Jump Boost (unique to this item, applied directly).
 */
public class WindcallerHandler implements MagicItemHandler {

    private final Xsibion plugin;

    public WindcallerHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public MagicItemId getId() {
        return MagicItemId.WINDCALLER;
    }

    @Override
    public void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        int jumpAmp = levelDef.getInt("jump-amplifier", 0);
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, jumpAmp, false, false, true));
        SpeedEffectCoordinator.recalculate(plugin, player);
    }

    @Override
    public void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        player.removePotionEffect(PotionEffectType.JUMP_BOOST);
        SpeedEffectCoordinator.recalculate(plugin, player);
    }
}
