package me.xsibion.item;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.util.MessageUtil;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;

/**
 * Central registry + logic hub for the Magic Item system. Magic Items are
 * equipped/unequipped purely through the GUI (not hotbar items like Skills) -
 * while equipped, their passive gameplay effect runs continuously, subject to
 * the player's Magic Item slot cap.
 */
public class MagicItemManager {

    private final Xsibion plugin;
    private final Map<MagicItemId, MagicItemDefinition> definitions = new EnumMap<>(MagicItemId.class);
    private final Map<MagicItemId, MagicItemHandler> handlers = new EnumMap<>(MagicItemId.class);

    public MagicItemManager(Xsibion plugin) {
        this.plugin = plugin;
        loadDefinitions();
    }

    public void loadDefinitions() {
        definitions.clear();
        ConfigurationSection itemsSection = plugin.getConfig().getConfigurationSection("magic-items");
        if (itemsSection == null) {
            return;
        }
        for (MagicItemId id : MagicItemId.values()) {
            ConfigurationSection section = itemsSection.getConfigurationSection(id.key());
            if (section != null) {
                definitions.put(id, new MagicItemDefinition(id, section));
            }
        }
    }

    public void registerHandler(MagicItemHandler handler) {
        handlers.put(handler.getId(), handler);
    }

    public MagicItemHandler getHandler(MagicItemId id) {
        return handlers.get(id);
    }

    public Map<MagicItemId, MagicItemHandler> getHandlers() {
        return handlers;
    }

    public MagicItemDefinition getDefinition(MagicItemId id) {
        return definitions.get(id);
    }

    public Map<MagicItemId, MagicItemDefinition> getDefinitions() {
        return definitions;
    }

    // ---------------- Unlock / Upgrade ----------------

    private boolean hasMaterials(Player player, Map<Material, Integer> materials) {
        for (Map.Entry<Material, Integer> entry : materials.entrySet()) {
            if (!player.getInventory().containsAtLeast(new ItemStack(entry.getKey()), entry.getValue())) {
                return false;
            }
        }
        return true;
    }

    private void consumeMaterials(Player player, Map<Material, Integer> materials) {
        for (Map.Entry<Material, Integer> entry : materials.entrySet()) {
            player.getInventory().removeItem(new ItemStack(entry.getKey(), entry.getValue()));
        }
    }

    public boolean canAffordNextLevel(Player player, MagicItemId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int current = data.getMagicItemLevel(id.key());
        MagicItemDefinition def = definitions.get(id);
        if (def == null || !def.hasLevel(current + 1)) {
            return false;
        }
        MagicItemLevelDefinition next = def.getLevel(current + 1);
        return data.getArcana() >= next.getUnlockCostArcana() && hasMaterials(player, next.getUnlockMaterials());
    }

    public boolean unlockNextLevel(Player player, MagicItemId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int current = data.getMagicItemLevel(id.key());
        MagicItemDefinition def = definitions.get(id);
        if (def == null || !def.hasLevel(current + 1)) {
            return false;
        }
        MagicItemLevelDefinition next = def.getLevel(current + 1);

        if (data.getArcana() < next.getUnlockCostArcana()) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.not-enough-arcana"));
            return false;
        }
        if (!hasMaterials(player, next.getUnlockMaterials())) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.craft-missing-ingredients"));
            return false;
        }

        data.spendArcana(next.getUnlockCostArcana());
        consumeMaterials(player, next.getUnlockMaterials());
        data.setMagicItemLevel(id.key(), current + 1);

        String msgKey = current == 0 ? "messages.item-unlocked" : "messages.item-upgraded";
        String msg = plugin.getConfig().getString(msgKey, "");
        msg = MessageUtil.replace(msg, "%item%", def.getDisplayName());
        msg = MessageUtil.replace(msg, "%level%", String.valueOf(current + 1));
        MessageUtil.send(player, msg);

        // refresh the running effect if it's currently equipped
        if (data.isMagicItemEquipped(id.key())) {
            MagicItemHandler handler = handlers.get(id);
            if (handler != null) {
                handler.onUnequip(player, data, def.getLevel(current));
                handler.onEquip(player, data, def.getLevel(current + 1));
            }
        }
        return true;
    }

    // ---------------- Equip / Unequip ----------------

    public int getMaxItemSlots(PlayerData data) {
        int def = plugin.getConfig().getInt("magic-item-slots.default", 3);
        int max = plugin.getConfig().getInt("magic-item-slots.maximum", 7);
        return Math.min(max, def + data.getPurchasedMagicItemSlots());
    }

    public boolean equipItem(Player player, MagicItemId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.getMagicItemLevel(id.key()) <= 0) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.skill-locked"));
            return false;
        }
        if (data.isMagicItemEquipped(id.key())) {
            return true;
        }
        if (data.getEquippedMagicItemCount() >= getMaxItemSlots(data)) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.no-free-item-slot"));
            return false;
        }
        data.setMagicItemEquipped(id.key(), true);
        MagicItemDefinition def = definitions.get(id);
        MagicItemHandler handler = handlers.get(id);
        int level = data.getMagicItemLevel(id.key());
        if (handler != null && def != null) {
            handler.onEquip(player, data, def.getLevel(level));
        }
        String msg = plugin.getConfig().getString("messages.item-equipped", "");
        msg = MessageUtil.replace(msg, "%item%", def.getDisplayName());
        MessageUtil.send(player, msg);
        return true;
    }

    public void unequipItem(Player player, MagicItemId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (!data.isMagicItemEquipped(id.key())) {
            return;
        }
        MagicItemDefinition def = definitions.get(id);
        MagicItemHandler handler = handlers.get(id);
        int level = data.getMagicItemLevel(id.key());
        data.setMagicItemEquipped(id.key(), false);
        if (handler != null && def != null && level > 0) {
            handler.onUnequip(player, data, def.getLevel(level));
        }
        String msg = plugin.getConfig().getString("messages.item-unequipped", "");
        msg = MessageUtil.replace(msg, "%item%", def != null ? def.getDisplayName() : id.key());
        MessageUtil.send(player, msg);
    }

    public void toggleEquip(Player player, MagicItemId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.isMagicItemEquipped(id.key())) {
            unequipItem(player, id);
        } else {
            equipItem(player, id);
        }
    }

    /**
     * Re-applies passive effects for all currently-equipped Magic Items.
     * Called on join since potion-effect-based passives do not survive a relog.
     */
    public void reapplyEquippedEffects(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        for (MagicItemId id : MagicItemId.values()) {
            if (data.isMagicItemEquipped(id.key())) {
                MagicItemDefinition def = definitions.get(id);
                MagicItemHandler handler = handlers.get(id);
                int level = data.getMagicItemLevel(id.key());
                if (handler != null && def != null && level > 0) {
                    handler.onEquip(player, data, def.getLevel(level));
                }
            }
        }
    }

    public void disableAllOnQuit(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        for (MagicItemId id : MagicItemId.values()) {
            if (data.isMagicItemEquipped(id.key())) {
                MagicItemDefinition def = definitions.get(id);
                MagicItemHandler handler = handlers.get(id);
                int level = data.getMagicItemLevel(id.key());
                if (handler != null && def != null && level > 0) {
                    handler.onUnequip(player, data, def.getLevel(level));
                }
            }
        }
    }
}
