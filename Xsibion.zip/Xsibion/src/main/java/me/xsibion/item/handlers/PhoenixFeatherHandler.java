package me.xsibion.item.handlers;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Phoenix Feather: survival and recovery abilities - prevents a fatal hit
 * from killing the player (once, then goes on a cooldown scaled by level).
 */
public class PhoenixFeatherHandler implements MagicItemHandler, Listener {

    private final Xsibion plugin;

    public PhoenixFeatherHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public MagicItemId getId() {
        return MagicItemId.PHOENIX_FEATHER;
    }

    @Override
    public void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // handled reactively in the damage listener
    }

    @Override
    public void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getMagicItemLevel(MagicItemId.PHOENIX_FEATHER.key());
        if (level <= 0 || !data.isMagicItemEquipped(MagicItemId.PHOENIX_FEATHER.key())) {
            return;
        }
        if (event.getFinalDamage() < player.getHealth()) {
            return; // not a lethal hit
        }
        if (data.isMagicItemOnCooldown(MagicItemId.PHOENIX_FEATHER.key())) {
            return; // still recharging, death proceeds normally
        }

        MagicItemLevelDefinition levelDef = plugin.getMagicItemManager().getDefinition(MagicItemId.PHOENIX_FEATHER).getLevel(level);
        double restoreHealth = levelDef.getDouble("restore-health", 4.0);
        double cooldown = levelDef.getDouble("cooldown-seconds", 300.0);

        event.setCancelled(true);
        data.setMagicItemCooldown(MagicItemId.PHOENIX_FEATHER.key(), cooldown);

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            player.setHealth(Math.min(restoreHealth, player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue()));
            player.setFireTicks(0);
            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 100, 0));
            player.getWorld().spawnParticle(org.bukkit.Particle.FLAME, player.getLocation().add(0, 1, 0), 40, 0.5, 1.0, 0.5, 0.05);
            player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
        });
    }
}
