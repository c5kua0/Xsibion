package me.xsibion.item;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.Map;

public class MagicItemDefinition {

    private final MagicItemId id;
    private final String displayName;
    private final Material icon;
    private final String description;
    private final Map<Integer, MagicItemLevelDefinition> levels = new HashMap<>();

    public MagicItemDefinition(MagicItemId id, ConfigurationSection section) {
        this.id = id;
        this.displayName = section.getString("display-name", id.name());
        Material iconMat = Material.matchMaterial(section.getString("icon", "PAPER"));
        this.icon = iconMat != null ? iconMat : Material.PAPER;
        this.description = section.getString("description", "");

        if (section.isConfigurationSection("levels")) {
            ConfigurationSection levelsSection = section.getConfigurationSection("levels");
            for (String levelKey : levelsSection.getKeys(false)) {
                try {
                    int level = Integer.parseInt(levelKey);
                    levels.put(level, new MagicItemLevelDefinition(level, levelsSection.getConfigurationSection(levelKey)));
                } catch (NumberFormatException ignored) {
                    // skip malformed level keys
                }
            }
        }
    }

    public MagicItemId getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getIcon() {
        return icon;
    }

    public String getDescription() {
        return description;
    }

    public int getMaxLevel() {
        return levels.size();
    }

    public MagicItemLevelDefinition getLevel(int level) {
        return levels.get(level);
    }

    public boolean hasLevel(int level) {
        return levels.containsKey(level);
    }
}
