package me.xsibion.item;

import me.xsibion.player.PlayerData;
import org.bukkit.entity.Player;

/**
 * Implements the actual gameplay mechanic for one Magic Item.
 * Called by MagicItemManager when the item is equipped/unequipped via the GUI.
 */
public interface MagicItemHandler {

    MagicItemId getId();

    void onEquip(Player player, PlayerData data, MagicItemLevelDefinition levelDef);

    void onUnequip(Player player, PlayerData data, MagicItemLevelDefinition levelDef);
}
