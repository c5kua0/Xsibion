package me.xsibion;

import me.xsibion.arcana.ArcanaManager;
import me.xsibion.command.XsibionCommand;
import me.xsibion.crafting.CraftingManager;
import me.xsibion.gui.GUIListener;
import me.xsibion.item.MagicItemHandler;
import me.xsibion.item.MagicItemManager;
import me.xsibion.item.handlers.GuardianShieldHandler;
import me.xsibion.item.handlers.LifebloomHandler;
import me.xsibion.item.handlers.MoonstoneHandler;
import me.xsibion.item.handlers.PhoenixFeatherHandler;
import me.xsibion.item.handlers.StormcoreHandler;
import me.xsibion.item.handlers.ThorncoreHandler;
import me.xsibion.item.handlers.WindcallerHandler;
import me.xsibion.listener.ArcanaListener;
import me.xsibion.listener.PlayerJoinQuitListener;
import me.xsibion.listener.SkillToggleListener;
import me.xsibion.player.PlayerDataManager;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillManager;
import me.xsibion.skill.handlers.ArcaneFocusSkillHandler;
import me.xsibion.skill.handlers.ArcaneShieldSkillHandler;
import me.xsibion.skill.handlers.FeatherfallSkillHandler;
import me.xsibion.skill.handlers.FireballSkillHandler;
import me.xsibion.skill.handlers.HasteSkillHandler;
import me.xsibion.skill.handlers.HealingSkillHandler;
import me.xsibion.skill.handlers.IronSkinSkillHandler;
import me.xsibion.skill.handlers.PowerUpSkillHandler;
import me.xsibion.skill.handlers.QuickstepSkillHandler;
import me.xsibion.skill.handlers.WaterwalkSkillHandler;
import me.xsibion.util.XsibionKeys;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Xsibion - a custom Skills, Magic Items, Arcana currency and Xsibion
 * crafting plugin for Paper servers. Every player can use /xsibion.
 */
public final class Xsibion extends JavaPlugin {

    private PlayerDataManager playerDataManager;
    private ArcanaManager arcanaManager;
    private SkillManager skillManager;
    private MagicItemManager magicItemManager;
    private CraftingManager craftingManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        XsibionKeys.init(this);

        this.playerDataManager = new PlayerDataManager(this);
        this.arcanaManager = new ArcanaManager(this);
        this.skillManager = new SkillManager(this);
        this.magicItemManager = new MagicItemManager(this);
        this.craftingManager = new CraftingManager(this);

        registerSkillHandlers();
        registerMagicItemHandlers();
        registerListeners();

        XsibionCommand commandExecutor = new XsibionCommand(this);
        var xsibionCommand = getCommand("xsibion");
        if (xsibionCommand != null) {
            xsibionCommand.setExecutor(commandExecutor);
        } else {
            getLogger().warning("The 'xsibion' command is missing from plugin.yml!");
        }

        // Periodically autosave everyone's data so a crash never loses much progress.
        getServer().getScheduler().runTaskTimer(this, () -> playerDataManager.saveAll(), 6000L, 6000L);

        getLogger().info("Xsibion has been enabled.");
    }

    @Override
    public void onDisable() {
        if (playerDataManager != null) {
            for (Player player : getServer().getOnlinePlayers()) {
                if (skillManager != null) {
                    skillManager.disableAllOnQuit(player);
                }
                if (magicItemManager != null) {
                    magicItemManager.disableAllOnQuit(player);
                }
            }
            playerDataManager.saveAll();
        }
        getLogger().info("Xsibion has been disabled.");
    }

    private void registerSkillHandlers() {
        skillManager.registerHandler(new FireballSkillHandler(this));
        skillManager.registerHandler(new HealingSkillHandler(this));
        skillManager.registerHandler(new PowerUpSkillHandler(this));
        skillManager.registerHandler(new QuickstepSkillHandler(this));
        skillManager.registerHandler(new IronSkinSkillHandler(this));
        skillManager.registerHandler(new HasteSkillHandler(this));
        skillManager.registerHandler(new FeatherfallSkillHandler(this));
        skillManager.registerHandler(new WaterwalkSkillHandler(this));
        skillManager.registerHandler(new ArcaneFocusSkillHandler(this));
        skillManager.registerHandler(new ArcaneShieldSkillHandler(this));

        for (SkillHandler handler : skillManager.getHandlers().values()) {
            if (handler instanceof Listener) {
                getServer().getPluginManager().registerEvents((Listener) handler, this);
            }
        }
    }

    private void registerMagicItemHandlers() {
        magicItemManager.registerHandler(new WindcallerHandler(this));
        magicItemManager.registerHandler(new GuardianShieldHandler(this));
        magicItemManager.registerHandler(new PhoenixFeatherHandler(this));
        magicItemManager.registerHandler(new LifebloomHandler(this));
        magicItemManager.registerHandler(new StormcoreHandler(this));
        magicItemManager.registerHandler(new MoonstoneHandler(this));
        magicItemManager.registerHandler(new ThorncoreHandler(this));

        for (MagicItemHandler handler : magicItemManager.getHandlers().values()) {
            if (handler instanceof Listener) {
                getServer().getPluginManager().registerEvents((Listener) handler, this);
            }
        }
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new ArcanaListener(this), this);
        getServer().getPluginManager().registerEvents(new SkillToggleListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerJoinQuitListener(this), this);
    }

    /**
     * Reloads config.yml and every definition/recipe loaded from it. Player
     * data, active toggles and equips are untouched.
     */
    public void reloadXsibionConfig() {
        reloadConfig();
        skillManager.loadDefinitions();
        magicItemManager.loadDefinitions();
        craftingManager.loadRecipes();
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public ArcanaManager getArcanaManager() {
        return arcanaManager;
    }

    public SkillManager getSkillManager() {
        return skillManager;
    }

    public MagicItemManager getMagicItemManager() {
        return magicItemManager;
    }

    public CraftingManager getCraftingManager() {
        return craftingManager;
    }
}
