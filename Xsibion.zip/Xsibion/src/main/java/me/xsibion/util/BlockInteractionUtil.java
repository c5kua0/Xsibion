package me.xsibion.util;

import org.bukkit.Material;

/**
 * Helper for detecting "interactable" blocks (chests, doors, buttons, crafting
 * stations, etc.) so skill toggling and Fireball casting don't fire when the
 * player is really just trying to open a container or use a door.
 */
public final class BlockInteractionUtil {

    private BlockInteractionUtil() {
    }

    public static boolean isInteractable(Material material) {
        if (material == null || material.isAir()) {
            return false;
        }
        String name = material.name();
        if (name.endsWith("_DOOR") || name.endsWith("_TRAPDOOR") || name.endsWith("_BUTTON")
                || name.endsWith("_FENCE_GATE") || name.endsWith("_BED") || name.endsWith("_SIGN")
                || name.endsWith("_SHULKER_BOX") || name.endsWith("_HANGING_SIGN")) {
            return true;
        }
        switch (material) {
            case CHEST:
            case TRAPPED_CHEST:
            case ENDER_CHEST:
            case BARREL:
            case FURNACE:
            case BLAST_FURNACE:
            case SMOKER:
            case CRAFTING_TABLE:
            case ANVIL:
            case CHIPPED_ANVIL:
            case DAMAGED_ANVIL:
            case ENCHANTING_TABLE:
            case BREWING_STAND:
            case BEACON:
            case LEVER:
            case JUKEBOX:
            case NOTE_BLOCK:
            case COMPARATOR:
            case REPEATER:
            case LOOM:
            case CARTOGRAPHY_TABLE:
            case GRINDSTONE:
            case SMITHING_TABLE:
            case STONECUTTER:
            case LECTERN:
            case COMPOSTER:
            case HOPPER:
            case DROPPER:
            case DISPENSER:
                return true;
            default:
                return false;
        }
    }
}
