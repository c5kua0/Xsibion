package me.xsibion.util;

import me.xsibion.Xsibion;
import org.bukkit.NamespacedKey;

/**
 * Central registry of every NamespacedKey used for PersistentDataContainer tags.
 */
public final class XsibionKeys {

    private XsibionKeys() {
    }

    public static NamespacedKey SKILL_ID;
    public static NamespacedKey SKILL_ITEM_MARKER;
    public static NamespacedKey MAGIC_ITEM_MARKER;
    public static NamespacedKey MAGIC_ITEM_ID;
    public static NamespacedKey PROJECTILE_MARKER;
    public static NamespacedKey PROJECTILE_DAMAGE;
    public static NamespacedKey PROJECTILE_FIRE_TICKS;
    public static NamespacedKey PROJECTILE_OWNER;
    public static NamespacedKey GUI_ACTION;
    public static NamespacedKey GUI_TARGET_ID;
    public static NamespacedKey GUI_TARGET_LEVEL;

    public static void init(Xsibion plugin) {
        SKILL_ID = new NamespacedKey(plugin, "skill_id");
        SKILL_ITEM_MARKER = new NamespacedKey(plugin, "skill_item_marker");
        MAGIC_ITEM_MARKER = new NamespacedKey(plugin, "magic_item_marker");
        MAGIC_ITEM_ID = new NamespacedKey(plugin, "magic_item_id");
        PROJECTILE_MARKER = new NamespacedKey(plugin, "projectile_marker");
        PROJECTILE_DAMAGE = new NamespacedKey(plugin, "projectile_damage");
        PROJECTILE_FIRE_TICKS = new NamespacedKey(plugin, "projectile_fire_ticks");
        PROJECTILE_OWNER = new NamespacedKey(plugin, "projectile_owner");
        GUI_ACTION = new NamespacedKey(plugin, "gui_action");
        GUI_TARGET_ID = new NamespacedKey(plugin, "gui_target_id");
        GUI_TARGET_LEVEL = new NamespacedKey(plugin, "gui_target_level");
    }
}
