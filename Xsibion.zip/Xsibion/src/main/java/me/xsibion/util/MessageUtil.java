package me.xsibion.util;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

/**
 * Small helper around message colouring and placeholder replacement.
 */
public final class MessageUtil {

    private MessageUtil() {
    }

    public static String color(String input) {
        if (input == null) {
            return "";
        }
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    public static void send(CommandSender sender, String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        sender.sendMessage(color(message));
    }

    public static String replace(String input, String placeholder, String value) {
        if (input == null) {
            return "";
        }
        return input.replace(placeholder, value);
    }
}
