package me.xsibion.util;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemDefinition;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillDefinition;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Three different sources can grant a SPEED potion effect: the Quickstep skill,
 * the Windcaller Magic Item, and Moonstone's night-time bonus. Rather than each
 * one blindly adding/removing PotionEffectType.SPEED (which would clobber the
 * others), every source funnels through here: it recomputes the strongest
 * currently-active amplifier from all three sources and applies (or clears)
 * a single SPEED effect accordingly.
 */
public final class SpeedEffectCoordinator {

    private SpeedEffectCoordinator() {
    }

    public static void recalculate(Xsibion plugin, Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int bestAmplifier = -1;

        // Quickstep skill
        int quickstepLevel = data.getSkillLevel(SkillId.QUICKSTEP.key());
        if (quickstepLevel > 0 && data.isSkillToggledOn(SkillId.QUICKSTEP.key())) {
            SkillDefinition def = plugin.getSkillManager().getDefinition(SkillId.QUICKSTEP);
            if (def != null) {
                SkillLevelDefinition levelDef = def.getLevel(quickstepLevel);
                if (levelDef != null) {
                    bestAmplifier = Math.max(bestAmplifier, levelDef.getInt("speed-amplifier", 0));
                }
            }
        }

        // Windcaller magic item
        int windcallerLevel = data.getMagicItemLevel(MagicItemId.WINDCALLER.key());
        if (windcallerLevel > 0 && data.isMagicItemEquipped(MagicItemId.WINDCALLER.key())) {
            MagicItemDefinition def = plugin.getMagicItemManager().getDefinition(MagicItemId.WINDCALLER);
            if (def != null) {
                MagicItemLevelDefinition levelDef = def.getLevel(windcallerLevel);
                if (levelDef != null) {
                    bestAmplifier = Math.max(bestAmplifier, levelDef.getInt("speed-amplifier", 0));
                }
            }
        }

        // Moonstone night-time bonus
        int moonstoneLevel = data.getMagicItemLevel(MagicItemId.MOONSTONE.key());
        if (moonstoneLevel > 0 && data.isMagicItemEquipped(MagicItemId.MOONSTONE.key()) && isNight(player)) {
            MagicItemDefinition def = plugin.getMagicItemManager().getDefinition(MagicItemId.MOONSTONE);
            if (def != null) {
                MagicItemLevelDefinition levelDef = def.getLevel(moonstoneLevel);
                if (levelDef != null) {
                    bestAmplifier = Math.max(bestAmplifier, levelDef.getInt("night-speed-amplifier", 0));
                }
            }
        }

        if (bestAmplifier >= 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, bestAmplifier, false, false, true));
        } else {
            player.removePotionEffect(PotionEffectType.SPEED);
        }
    }

    public static boolean isNight(Player player) {
        long time = player.getWorld().getTime();
        return time >= 13000 && time <= 23000;
    }
}
