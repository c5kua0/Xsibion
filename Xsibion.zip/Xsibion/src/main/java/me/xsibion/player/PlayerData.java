package me.xsibion.player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Holds all persistent Xsibion state for a single player, plus a few
 * runtime-only (non-persisted) fields used for cooldown tracking.
 */
public class PlayerData {

    private final UUID uuid;

    private double arcana;

    // skillId -> unlocked level (0 = locked, 1-3 = Early/Mid/Late)
    private final Map<String, Integer> skillLevels = new HashMap<>();
    // skillId -> hotbar slot (0-8) it is equipped to, or -1 if not equipped
    private final Map<String, Integer> equippedSkillSlots = new HashMap<>();
    // skillId -> toggle on/off state
    private final Map<String, Boolean> skillToggleStates = new HashMap<>();

    // magicItemId -> unlocked level (0 = locked, 1-3)
    private final Map<String, Integer> magicItemLevels = new HashMap<>();
    // magicItemId -> equipped (true/false)
    private final Map<String, Boolean> equippedMagicItems = new HashMap<>();

    private int purchasedSkillSlots = 0;
    private int purchasedMagicItemSlots = 0;

    // ---- runtime-only (not saved) ----
    private final transient Map<String, Long> skillCooldowns = new HashMap<>();
    private final transient Map<String, Long> magicItemCooldowns = new HashMap<>();
    private final transient Map<String, Double> arcaneShieldCharge = new HashMap<>();

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() {
        return uuid;
    }

    public double getArcana() {
        return arcana;
    }

    public void setArcana(double arcana) {
        this.arcana = Math.max(0, arcana);
    }

    public void addArcana(double amount) {
        this.arcana = Math.max(0, this.arcana + amount);
    }

    public boolean spendArcana(double amount) {
        if (arcana + 1.0E-6 < amount) {
            return false;
        }
        arcana -= amount;
        if (arcana < 0) {
            arcana = 0;
        }
        return true;
    }

    public int getSkillLevel(String skillId) {
        return skillLevels.getOrDefault(skillId, 0);
    }

    public void setSkillLevel(String skillId, int level) {
        skillLevels.put(skillId, level);
    }

    public Map<String, Integer> getSkillLevels() {
        return skillLevels;
    }

    public int getEquippedSlot(String skillId) {
        return equippedSkillSlots.getOrDefault(skillId, -1);
    }

    public void setEquippedSlot(String skillId, int slot) {
        if (slot < 0) {
            equippedSkillSlots.remove(skillId);
        } else {
            equippedSkillSlots.put(skillId, slot);
        }
    }

    public Map<String, Integer> getEquippedSkillSlots() {
        return equippedSkillSlots;
    }

    public String getSkillEquippedInSlot(int slot) {
        for (Map.Entry<String, Integer> entry : equippedSkillSlots.entrySet()) {
            if (entry.getValue() == slot) {
                return entry.getKey();
            }
        }
        return null;
    }

    public boolean isSkillToggledOn(String skillId) {
        return skillToggleStates.getOrDefault(skillId, false);
    }

    public void setSkillToggledOn(String skillId, boolean on) {
        skillToggleStates.put(skillId, on);
    }

    public Map<String, Boolean> getSkillToggleStates() {
        return skillToggleStates;
    }

    public int getMagicItemLevel(String itemId) {
        return magicItemLevels.getOrDefault(itemId, 0);
    }

    public void setMagicItemLevel(String itemId, int level) {
        magicItemLevels.put(itemId, level);
    }

    public Map<String, Integer> getMagicItemLevels() {
        return magicItemLevels;
    }

    public boolean isMagicItemEquipped(String itemId) {
        return equippedMagicItems.getOrDefault(itemId, false);
    }

    public void setMagicItemEquipped(String itemId, boolean equipped) {
        equippedMagicItems.put(itemId, equipped);
    }

    public Map<String, Boolean> getEquippedMagicItems() {
        return equippedMagicItems;
    }

    public int getEquippedMagicItemCount() {
        int count = 0;
        for (boolean b : equippedMagicItems.values()) {
            if (b) {
                count++;
            }
        }
        return count;
    }

    public int getPurchasedSkillSlots() {
        return purchasedSkillSlots;
    }

    public void setPurchasedSkillSlots(int purchasedSkillSlots) {
        this.purchasedSkillSlots = purchasedSkillSlots;
    }

    public int getPurchasedMagicItemSlots() {
        return purchasedMagicItemSlots;
    }

    public void setPurchasedMagicItemSlots(int purchasedMagicItemSlots) {
        this.purchasedMagicItemSlots = purchasedMagicItemSlots;
    }

    // ---- runtime cooldown helpers ----

    public boolean isSkillOnCooldown(String skillId) {
        Long until = skillCooldowns.get(skillId);
        return until != null && until > System.currentTimeMillis();
    }

    public double getSkillCooldownSecondsRemaining(String skillId) {
        Long until = skillCooldowns.get(skillId);
        if (until == null) {
            return 0;
        }
        return Math.max(0, (until - System.currentTimeMillis()) / 1000.0);
    }

    public void setSkillCooldown(String skillId, double seconds) {
        skillCooldowns.put(skillId, System.currentTimeMillis() + (long) (seconds * 1000L));
    }

    public boolean isMagicItemOnCooldown(String itemId) {
        Long until = magicItemCooldowns.get(itemId);
        return until != null && until > System.currentTimeMillis();
    }

    public void setMagicItemCooldown(String itemId, double seconds) {
        magicItemCooldowns.put(itemId, System.currentTimeMillis() + (long) (seconds * 1000L));
    }

    public double getArcaneShieldCharge(String skillId, double max) {
        return arcaneShieldCharge.getOrDefault(skillId, max);
    }

    public void setArcaneShieldCharge(String skillId, double value) {
        arcaneShieldCharge.put(skillId, value);
    }
}
