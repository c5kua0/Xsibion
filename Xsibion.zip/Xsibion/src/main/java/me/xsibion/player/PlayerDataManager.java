package me.xsibion.player;

import me.xsibion.Xsibion;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Loads, caches and persists PlayerData to individual YAML files under
 * plugins/Xsibion/playerdata/&lt;uuid&gt;.yml
 */
public class PlayerDataManager {

    private final Xsibion plugin;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();
    private final File dataFolder;

    public PlayerDataManager(Xsibion plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }

    public PlayerData get(Player player) {
        return get(player.getUniqueId());
    }

    public PlayerData get(UUID uuid) {
        return cache.computeIfAbsent(uuid, this::load);
    }

    public boolean isLoaded(UUID uuid) {
        return cache.containsKey(uuid);
    }

    public void unload(UUID uuid) {
        cache.remove(uuid);
    }

    private File fileFor(UUID uuid) {
        return new File(dataFolder, uuid.toString() + ".yml");
    }

    public PlayerData load(UUID uuid) {
        PlayerData data = new PlayerData(uuid);
        File file = fileFor(uuid);
        if (!file.exists()) {
            return data;
        }

        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        data.setArcana(cfg.getDouble("arcana", 0.0));
        data.setPurchasedSkillSlots(cfg.getInt("purchased-skill-slots", 0));
        data.setPurchasedMagicItemSlots(cfg.getInt("purchased-magic-item-slots", 0));

        if (cfg.isConfigurationSection("skills.levels")) {
            for (String key : cfg.getConfigurationSection("skills.levels").getKeys(false)) {
                data.setSkillLevel(key, cfg.getInt("skills.levels." + key));
            }
        }
        if (cfg.isConfigurationSection("skills.equipped")) {
            for (String key : cfg.getConfigurationSection("skills.equipped").getKeys(false)) {
                data.setEquippedSlot(key, cfg.getInt("skills.equipped." + key));
            }
        }
        if (cfg.isConfigurationSection("skills.toggled")) {
            for (String key : cfg.getConfigurationSection("skills.toggled").getKeys(false)) {
                data.setSkillToggledOn(key, cfg.getBoolean("skills.toggled." + key));
            }
        }

        if (cfg.isConfigurationSection("items.levels")) {
            for (String key : cfg.getConfigurationSection("items.levels").getKeys(false)) {
                data.setMagicItemLevel(key, cfg.getInt("items.levels." + key));
            }
        }
        if (cfg.isConfigurationSection("items.equipped")) {
            for (String key : cfg.getConfigurationSection("items.equipped").getKeys(false)) {
                data.setMagicItemEquipped(key, cfg.getBoolean("items.equipped." + key));
            }
        }

        return data;
    }

    public void save(UUID uuid) {
        PlayerData data = cache.get(uuid);
        if (data == null) {
            return;
        }
        save(data);
    }

    public void save(PlayerData data) {
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("arcana", data.getArcana());
        cfg.set("purchased-skill-slots", data.getPurchasedSkillSlots());
        cfg.set("purchased-magic-item-slots", data.getPurchasedMagicItemSlots());

        for (Map.Entry<String, Integer> entry : data.getSkillLevels().entrySet()) {
            cfg.set("skills.levels." + entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, Integer> entry : data.getEquippedSkillSlots().entrySet()) {
            cfg.set("skills.equipped." + entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, Boolean> entry : data.getSkillToggleStates().entrySet()) {
            cfg.set("skills.toggled." + entry.getKey(), entry.getValue());
        }

        for (Map.Entry<String, Integer> entry : data.getMagicItemLevels().entrySet()) {
            cfg.set("items.levels." + entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, Boolean> entry : data.getEquippedMagicItems().entrySet()) {
            cfg.set("items.equipped." + entry.getKey(), entry.getValue());
        }

        try {
            cfg.save(fileFor(data.getUuid()));
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save player data for " + data.getUuid() + ": " + e.getMessage());
        }
    }

    public void saveAll() {
        for (PlayerData data : cache.values()) {
            save(data);
        }
    }
}
