package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Healing: while toggled ON, periodically restores a chunk of the player's health.
 */
public class HealingSkillHandler implements SkillHandler {

    private final Xsibion plugin;
    private final Map<UUID, BukkitTask> tasks = new ConcurrentHashMap<>();

    public HealingSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.HEALING;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        stop(player.getUniqueId());
        double interval = levelDef.getDouble("interval-seconds", 8.0);
        double healAmount = levelDef.getDouble("heal-amount", 1.0);
        long periodTicks = Math.max(20L, (long) (interval * 20L));

        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || player.isDead()) {
                return;
            }
            PlayerData current = plugin.getPlayerDataManager().get(player);
            if (!current.isSkillToggledOn(SkillId.HEALING.key())) {
                stop(player.getUniqueId());
                return;
            }
            double bonusHeal = plugin.getSkillManager().applyArcaneFocusBonus(player, healAmount);
            double max = player.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null
                    ? player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue() : 20.0;
            double newHealth = Math.min(max, player.getHealth() + bonusHeal);
            player.setHealth(newHealth);
            player.getWorld().spawnParticle(org.bukkit.Particle.HEART, player.getLocation().add(0, 1, 0), 2, 0.3, 0.3, 0.3, 0);
        }, periodTicks, periodTicks);

        tasks.put(player.getUniqueId(), task);
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        stop(player.getUniqueId());
    }

    private void stop(UUID uuid) {
        BukkitTask task = tasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }
    }
}
