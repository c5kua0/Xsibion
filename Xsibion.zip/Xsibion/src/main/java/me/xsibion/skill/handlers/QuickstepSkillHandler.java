package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import me.xsibion.util.SpeedEffectCoordinator;
import org.bukkit.entity.Player;

/**
 * Quickstep: increases movement speed. Routed through SpeedEffectCoordinator
 * since Windcaller and Moonstone can also grant a SPEED effect.
 */
public class QuickstepSkillHandler implements SkillHandler {

    private final Xsibion plugin;

    public QuickstepSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.QUICKSTEP;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        SpeedEffectCoordinator.recalculate(plugin, player);
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        SpeedEffectCoordinator.recalculate(plugin, player);
    }
}
