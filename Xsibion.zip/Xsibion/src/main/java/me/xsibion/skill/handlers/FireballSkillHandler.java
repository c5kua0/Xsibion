package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import me.xsibion.util.MessageUtil;
import me.xsibion.util.XsibionKeys;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

/**
 * Fireball: plain right-click (not sneaking) while the skill is toggled ON
 * and the Fireball skill item is held launches a bolt of arcane fire.
 * Implemented via a tagged Snowball (not a real Fireball entity) so there is
 * zero terrain/block griefing risk - damage and fire ticks are applied
 * manually on impact.
 */
public class FireballSkillHandler implements SkillHandler, Listener {

    private final Xsibion plugin;

    public FireballSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.FIREBALL;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // no persistent state needed; casting is handled on interact
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() == null || !event.getHand().equals(org.bukkit.inventory.EquipmentSlot.HAND)) {
            return;
        }
        if (event.getPlayer().isSneaking()) {
            return; // sneaking + right click is the toggle gesture, handled elsewhere
        }
        switch (event.getAction()) {
            case RIGHT_CLICK_AIR:
                break;
            case RIGHT_CLICK_BLOCK:
                if (event.getClickedBlock() != null
                        && me.xsibion.util.BlockInteractionUtil.isInteractable(event.getClickedBlock().getType())) {
                    return; // let the player open the chest/door/etc. instead of casting
                }
                break;
            default:
                return;
        }

        Player player = event.getPlayer();
        ItemStack held = event.getItem();
        if (held == null || !plugin.getSkillManager().isSkillItem(held, SkillId.FIREBALL)) {
            return;
        }

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (!data.isSkillToggledOn(SkillId.FIREBALL.key())) {
            return;
        }
        int level = data.getSkillLevel(SkillId.FIREBALL.key());
        if (level <= 0) {
            return;
        }

        if (data.isSkillOnCooldown(SkillId.FIREBALL.key())) {
            String msg = plugin.getConfig().getString("messages.skill-cooldown", "");
            msg = MessageUtil.replace(msg, "%skill%", "Fireball");
            msg = MessageUtil.replace(msg, "%seconds%",
                    String.format("%.1f", data.getSkillCooldownSecondsRemaining(SkillId.FIREBALL.key())));
            MessageUtil.send(player, msg);
            return;
        }

        SkillLevelDefinition levelDef = plugin.getSkillManager().getDefinition(SkillId.FIREBALL).getLevel(level);
        double cooldown = levelDef.getDouble("cooldown-seconds", 3.0);
        double damage = plugin.getSkillManager().applyArcaneFocusBonus(player, levelDef.getDouble("damage", 4.0));
        int fireTicks = levelDef.getInt("fire-ticks", 20);

        data.setSkillCooldown(SkillId.FIREBALL.key(), cooldown);

        Snowball projectile = player.launchProjectile(Snowball.class);
        Vector direction = player.getEyeLocation().getDirection().normalize().multiply(1.4);
        projectile.setVelocity(direction);
        projectile.getPersistentDataContainer().set(XsibionKeys.PROJECTILE_MARKER, PersistentDataType.BYTE, (byte) 1);
        projectile.getPersistentDataContainer().set(XsibionKeys.PROJECTILE_DAMAGE, PersistentDataType.DOUBLE, damage);
        projectile.getPersistentDataContainer().set(XsibionKeys.PROJECTILE_FIRE_TICKS, PersistentDataType.INTEGER, fireTicks);
        projectile.getPersistentDataContainer().set(XsibionKeys.PROJECTILE_OWNER, PersistentDataType.STRING, player.getUniqueId().toString());

        player.getWorld().spawnParticle(org.bukkit.Particle.FLAME, player.getEyeLocation(), 12, 0.1, 0.1, 0.1, 0.02);
        player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.0f);
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile projectile = event.getEntity();
        if (!(projectile instanceof Snowball)) {
            return;
        }
        Byte marker = projectile.getPersistentDataContainer().get(XsibionKeys.PROJECTILE_MARKER, PersistentDataType.BYTE);
        if (marker == null || marker != 1) {
            return;
        }

        Double damage = projectile.getPersistentDataContainer().get(XsibionKeys.PROJECTILE_DAMAGE, PersistentDataType.DOUBLE);
        Integer fireTicks = projectile.getPersistentDataContainer().get(XsibionKeys.PROJECTILE_FIRE_TICKS, PersistentDataType.INTEGER);
        String ownerId = projectile.getPersistentDataContainer().get(XsibionKeys.PROJECTILE_OWNER, PersistentDataType.STRING);

        Entity hit = event.getHitEntity();
        if (hit instanceof LivingEntity && !(ownerId != null && hit.getUniqueId().toString().equals(ownerId))) {
            LivingEntity living = (LivingEntity) hit;
            living.damage(damage != null ? damage : 4.0);
            living.setFireTicks(Math.max(living.getFireTicks(), fireTicks != null ? fireTicks : 20));
        }
        projectile.getWorld().spawnParticle(org.bukkit.Particle.LAVA, event.getHitBlock() != null
                ? event.getHitBlock().getLocation().add(0.5, 0.5, 0.5) : projectile.getLocation(), 10, 0.2, 0.2, 0.2, 0.0);
        projectile.remove();
    }
}
