package me.xsibion.skill;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.util.ItemBuilder;
import me.xsibion.util.MessageUtil;
import me.xsibion.util.XsibionKeys;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.EnumMap;
import java.util.Map;

/**
 * Central registry + logic hub for the skill system: definitions, unlocking,
 * equipping, and toggling. Individual gameplay mechanics live in SkillHandler
 * implementations under skill.handlers.
 */
public class SkillManager {

    private final Xsibion plugin;
    private final Map<SkillId, SkillDefinition> definitions = new EnumMap<>(SkillId.class);
    private final Map<SkillId, SkillHandler> handlers = new EnumMap<>(SkillId.class);

    public SkillManager(Xsibion plugin) {
        this.plugin = plugin;
        loadDefinitions();
    }

    public void loadDefinitions() {
        definitions.clear();
        ConfigurationSection skillsSection = plugin.getConfig().getConfigurationSection("skills");
        if (skillsSection == null) {
            return;
        }
        for (SkillId id : SkillId.values()) {
            ConfigurationSection section = skillsSection.getConfigurationSection(id.key());
            if (section != null) {
                definitions.put(id, new SkillDefinition(id, section));
            }
        }
    }

    public void registerHandler(SkillHandler handler) {
        handlers.put(handler.getId(), handler);
    }

    public SkillHandler getHandler(SkillId id) {
        return handlers.get(id);
    }

    public Map<SkillId, SkillHandler> getHandlers() {
        return handlers;
    }

    public SkillDefinition getDefinition(SkillId id) {
        return definitions.get(id);
    }

    public Map<SkillId, SkillDefinition> getDefinitions() {
        return definitions;
    }

    // ---------------- Unlock / Upgrade ----------------

    public boolean canAffordNextLevel(Player player, SkillId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int current = data.getSkillLevel(id.key());
        SkillDefinition def = definitions.get(id);
        if (def == null || !def.hasLevel(current + 1)) {
            return false;
        }
        SkillLevelDefinition next = def.getLevel(current + 1);
        if (data.getArcana() < next.getUnlockCostArcana()) {
            return false;
        }
        return hasMaterials(player, next.getUnlockMaterials());
    }

    private boolean hasMaterials(Player player, Map<Material, Integer> materials) {
        for (Map.Entry<Material, Integer> entry : materials.entrySet()) {
            if (!player.getInventory().containsAtLeast(new ItemStack(entry.getKey()), entry.getValue())) {
                return false;
            }
        }
        return true;
    }

    private void consumeMaterials(Player player, Map<Material, Integer> materials) {
        for (Map.Entry<Material, Integer> entry : materials.entrySet()) {
            ItemStack toRemove = new ItemStack(entry.getKey(), entry.getValue());
            player.getInventory().removeItem(toRemove);
        }
    }

    /**
     * Attempts to unlock the next level of a skill for a player. Returns true on success.
     */
    public boolean unlockNextLevel(Player player, SkillId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int current = data.getSkillLevel(id.key());
        SkillDefinition def = definitions.get(id);
        if (def == null || !def.hasLevel(current + 1)) {
            return false;
        }
        SkillLevelDefinition next = def.getLevel(current + 1);

        if (data.getArcana() < next.getUnlockCostArcana()) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.not-enough-arcana"));
            return false;
        }
        if (!hasMaterials(player, next.getUnlockMaterials())) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.craft-missing-ingredients"));
            return false;
        }

        data.spendArcana(next.getUnlockCostArcana());
        consumeMaterials(player, next.getUnlockMaterials());
        data.setSkillLevel(id.key(), current + 1);

        String msgKey = current == 0 ? "messages.skill-unlocked" : "messages.skill-upgraded";
        String msg = plugin.getConfig().getString(msgKey, "");
        msg = MessageUtil.replace(msg, "%skill%", def.getDisplayName());
        msg = MessageUtil.replace(msg, "%level%", String.valueOf(current + 1));
        MessageUtil.send(player, msg);

        // if the skill was equipped & toggled on, refresh the item in the hotbar slot
        int slot = data.getEquippedSlot(id.key());
        if (slot >= 0) {
            giveSkillItem(player, id, slot);
        }
        return true;
    }

    // ---------------- Equip / Unequip ----------------

    public int getMaxSkillSlots(PlayerData data) {
        int def = plugin.getConfig().getInt("skill-slots.default", 5);
        int max = plugin.getConfig().getInt("skill-slots.maximum", 9);
        return Math.min(max, def + data.getPurchasedSkillSlots());
    }

    public boolean equipSkill(Player player, SkillId id, int hotbarSlot) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.getSkillLevel(id.key()) <= 0) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.skill-locked"));
            return false;
        }
        if (hotbarSlot < 0 || hotbarSlot > 8) {
            return false;
        }
        // free up anything currently in that slot mapping
        String occupying = data.getSkillEquippedInSlot(hotbarSlot);
        if (occupying != null) {
            unequipSkill(player, SkillId.fromKey(occupying));
        }
        data.setEquippedSlot(id.key(), hotbarSlot);
        giveSkillItem(player, id, hotbarSlot);

        String msg = plugin.getConfig().getString("messages.skill-equipped", "");
        msg = MessageUtil.replace(msg, "%skill%", definitions.get(id).getDisplayName());
        msg = MessageUtil.replace(msg, "%slot%", String.valueOf(hotbarSlot + 1));
        MessageUtil.send(player, msg);
        return true;
    }

    public void unequipSkill(Player player, SkillId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int slot = data.getEquippedSlot(id.key());
        if (slot < 0) {
            return;
        }
        if (data.isSkillToggledOn(id.key())) {
            setToggle(player, id, false);
        }
        data.setEquippedSlot(id.key(), -1);
        ItemStack current = player.getInventory().getItem(slot);
        if (current != null && isSkillItem(current, id)) {
            player.getInventory().setItem(slot, null);
        }
        String msg = plugin.getConfig().getString("messages.skill-unequipped", "");
        msg = MessageUtil.replace(msg, "%skill%", definitions.get(id).getDisplayName());
        MessageUtil.send(player, msg);
    }

    public boolean isSkillItem(ItemStack stack, SkillId id) {
        if (stack == null || stack.getItemMeta() == null) {
            return false;
        }
        String tag = stack.getItemMeta().getPersistentDataContainer()
                .get(XsibionKeys.SKILL_ID, PersistentDataType.STRING);
        return tag != null && tag.equals(id.key());
    }

    public SkillId getSkillFromItem(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) {
            return null;
        }
        String tag = stack.getItemMeta().getPersistentDataContainer()
                .get(XsibionKeys.SKILL_ID, PersistentDataType.STRING);
        return tag == null ? null : SkillId.fromKey(tag);
    }

    public ItemStack giveSkillItem(Player player, SkillId id, int hotbarSlot) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        SkillDefinition def = definitions.get(id);
        int level = data.getSkillLevel(id.key());
        SkillLevelDefinition levelDef = def.getLevel(Math.max(1, level));
        boolean on = data.isSkillToggledOn(id.key());

        ItemStack stack = new ItemBuilder(def.getIcon())
                .name((on ? "&a&l" : "&c&l") + def.getDisplayName() + " &7(" + (levelDef != null ? levelDef.getDisplaySuffix() : "I") + ")")
                .lore(java.util.List.of(
                        "&7" + def.getDescription(),
                        "",
                        "&7State: " + (on ? "&a&lON" : "&c&lOFF"),
                        "&7Shift + Right Click to toggle"
                ))
                .tag(XsibionKeys.SKILL_ID, PersistentDataType.STRING, id.key())
                .tag(XsibionKeys.SKILL_ITEM_MARKER, PersistentDataType.BYTE, (byte) 1)
                .build();

        player.getInventory().setItem(hotbarSlot, stack);
        return stack;
    }

    // ---------------- Toggle ----------------

    public void setToggle(Player player, SkillId id, boolean on) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        SkillDefinition def = definitions.get(id);
        int level = data.getSkillLevel(id.key());
        if (level <= 0) {
            return;
        }
        SkillLevelDefinition levelDef = def.getLevel(level);
        data.setSkillToggledOn(id.key(), on);

        SkillHandler handler = handlers.get(id);
        if (handler != null) {
            if (on) {
                handler.onToggleOn(player, data, levelDef);
            } else {
                handler.onToggleOff(player, data, levelDef);
            }
        }

        int slot = data.getEquippedSlot(id.key());
        if (slot >= 0) {
            giveSkillItem(player, id, slot);
        }

        String msg = plugin.getConfig().getString(on ? "messages.skill-on" : "messages.skill-off", "");
        msg = MessageUtil.replace(msg, "%skill%", def.getDisplayName());
        MessageUtil.send(player, msg);
    }

    public void toggleSkill(Player player, SkillId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        boolean current = data.isSkillToggledOn(id.key());
        setToggle(player, id, !current);
    }

    /**
     * Applies the player's Arcane Focus bonus (if unlocked & toggled on) to a base magnitude.
     */
    public double applyArcaneFocusBonus(Player player, double base) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int focusLevel = data.getSkillLevel(SkillId.ARCANE_FOCUS.key());
        if (focusLevel <= 0 || !data.isSkillToggledOn(SkillId.ARCANE_FOCUS.key())) {
            return base;
        }
        SkillDefinition focusDef = definitions.get(SkillId.ARCANE_FOCUS);
        if (focusDef == null) {
            return base;
        }
        SkillLevelDefinition levelDef = focusDef.getLevel(focusLevel);
        double bonusPercent = levelDef.getDouble("effect-bonus-percent", 0);
        return base * (1.0 + (bonusPercent / 100.0));
    }

    public void disableAllOnQuit(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        for (SkillId id : SkillId.values()) {
            if (data.isSkillToggledOn(id.key())) {
                SkillHandler handler = handlers.get(id);
                SkillDefinition def = definitions.get(id);
                if (handler != null && def != null) {
                    int level = data.getSkillLevel(id.key());
                    if (level > 0) {
                        handler.onToggleOff(player, data, def.getLevel(level));
                    }
                }
            }
        }
    }

    public Xsibion getPlugin() {
        return plugin;
    }
}
