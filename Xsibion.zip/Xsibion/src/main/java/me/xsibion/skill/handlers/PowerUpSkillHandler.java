package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.skill.SkillId;
import org.bukkit.potion.PotionEffectType;

/**
 * Power Up: increases attack damage via a Strength effect.
 */
public class PowerUpSkillHandler extends PotionToggleSkillHandler {

    public PowerUpSkillHandler(Xsibion plugin) {
        super(plugin, PotionEffectType.STRENGTH, "strength-amplifier");
    }

    @Override
    public SkillId getId() {
        return SkillId.POWER_UP;
    }
}
