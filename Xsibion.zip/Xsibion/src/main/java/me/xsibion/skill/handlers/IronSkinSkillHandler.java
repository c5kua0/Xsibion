package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Iron Skin: reduces incoming damage by a configured percentage while toggled ON.
 */
public class IronSkinSkillHandler implements SkillHandler, Listener {

    private final Xsibion plugin;

    public IronSkinSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.IRON_SKIN;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // handled reactively in the damage listener
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getSkillLevel(SkillId.IRON_SKIN.key());
        if (level <= 0 || !data.isSkillToggledOn(SkillId.IRON_SKIN.key())) {
            return;
        }
        SkillLevelDefinition levelDef = plugin.getSkillManager().getDefinition(SkillId.IRON_SKIN).getLevel(level);
        double percent = levelDef.getDouble("damage-reduction-percent", 0);
        double multiplier = Math.max(0, 1.0 - (percent / 100.0));
        event.setDamage(event.getDamage() * multiplier);
    }
}
