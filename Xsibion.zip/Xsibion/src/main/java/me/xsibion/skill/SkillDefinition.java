package me.xsibion.skill;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.Map;

/**
 * All configured data for one skill (all 3 levels), loaded from config.yml.
 */
public class SkillDefinition {

    private final SkillId id;
    private final String displayName;
    private final Material icon;
    private final String description;
    private final Map<Integer, SkillLevelDefinition> levels = new HashMap<>();

    public SkillDefinition(SkillId id, ConfigurationSection section) {
        this.id = id;
        this.displayName = section.getString("display-name", id.name());
        Material iconMat = Material.matchMaterial(section.getString("icon", "PAPER"));
        this.icon = iconMat != null ? iconMat : Material.PAPER;
        this.description = section.getString("description", "");

        if (section.isConfigurationSection("levels")) {
            ConfigurationSection levelsSection = section.getConfigurationSection("levels");
            for (String levelKey : levelsSection.getKeys(false)) {
                try {
                    int level = Integer.parseInt(levelKey);
                    levels.put(level, new SkillLevelDefinition(level, levelsSection.getConfigurationSection(levelKey)));
                } catch (NumberFormatException ignored) {
                    // skip malformed level keys
                }
            }
        }
    }

    public SkillId getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getIcon() {
        return icon;
    }

    public String getDescription() {
        return description;
    }

    public int getMaxLevel() {
        return levels.size();
    }

    public SkillLevelDefinition getLevel(int level) {
        return levels.get(level);
    }

    public boolean hasLevel(int level) {
        return levels.containsKey(level);
    }
}
