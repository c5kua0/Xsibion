package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Arcane Shield: while toggled ON, absorbs a chunk of a single incoming hit,
 * then goes on a recharge cooldown before it can absorb again.
 */
public class ArcaneShieldSkillHandler implements SkillHandler, Listener {

    private final Xsibion plugin;

    public ArcaneShieldSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.ARCANE_SHIELD;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // shield is immediately available; recharge state tracked via cooldown map
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getSkillLevel(SkillId.ARCANE_SHIELD.key());
        if (level <= 0 || !data.isSkillToggledOn(SkillId.ARCANE_SHIELD.key())) {
            return;
        }
        if (data.isSkillOnCooldown(SkillId.ARCANE_SHIELD.key())) {
            return; // shield is recharging
        }
        SkillLevelDefinition levelDef = plugin.getSkillManager().getDefinition(SkillId.ARCANE_SHIELD).getLevel(level);
        double absorption = plugin.getSkillManager().applyArcaneFocusBonus(player, levelDef.getDouble("absorption-amount", 4.0));
        double recharge = levelDef.getDouble("recharge-seconds", 20.0);

        double reduced = Math.max(0, event.getDamage() - absorption);
        event.setDamage(reduced);
        data.setSkillCooldown(SkillId.ARCANE_SHIELD.key(), recharge);

        player.getWorld().spawnParticle(org.bukkit.Particle.ENCHANT, player.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.5);
        player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.ITEM_SHIELD_BLOCK, 1.0f, 1.2f);
    }
}
