package me.xsibion.skill;

/**
 * The 10 core Xsibion skill categories. Each has 3 levels
 * (1 = Early Game, 2 = Mid Game, 3 = Late Game).
 */
public enum SkillId {

    FIREBALL("fireball"),
    HEALING("healing"),
    POWER_UP("power_up"),
    QUICKSTEP("quickstep"),
    IRON_SKIN("iron_skin"),
    HASTE("haste"),
    FEATHERFALL("featherfall"),
    WATERWALK("waterwalk"),
    ARCANE_FOCUS("arcane_focus"),
    ARCANE_SHIELD("arcane_shield");

    private final String configKey;

    SkillId(String configKey) {
        this.configKey = configKey;
    }

    public String key() {
        return configKey;
    }

    public static SkillId fromKey(String key) {
        for (SkillId id : values()) {
            if (id.configKey.equalsIgnoreCase(key)) {
                return id;
            }
        }
        return null;
    }
}
