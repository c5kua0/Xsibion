package me.xsibion.skill;

import me.xsibion.player.PlayerData;
import org.bukkit.entity.Player;

/**
 * Implements the actual gameplay mechanic for one skill category.
 * Called by the SkillManager when a skill is toggled on/off, and may also
 * register its own listeners for skill-specific triggers (attacks, damage, etc).
 */
public interface SkillHandler {

    SkillId getId();

    /**
     * Called the moment the skill is toggled ON.
     */
    void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef);

    /**
     * Called the moment the skill is toggled OFF (including on logout/unequip).
     */
    void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef);
}
