package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.entity.Player;

/**
 * Arcane Focus: self-only passive. Toggling it ON/OFF simply flips the flag
 * that SkillManager#applyArcaneFocusBonus reads when computing the magnitude
 * of every other skill's effect for this player. No ally/faction system exists -
 * the bonus only ever applies to the caster themselves.
 */
public class ArcaneFocusSkillHandler implements SkillHandler {

    private final Xsibion plugin;

    public ArcaneFocusSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.ARCANE_FOCUS;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // state flag is enough; read reactively by SkillManager#applyArcaneFocusBonus
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // nothing to clean up
    }
}
