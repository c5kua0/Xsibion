package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Featherfall: reduces (or at level 3, eliminates) fall damage while toggled ON.
 */
public class FeatherfallSkillHandler implements SkillHandler, Listener {

    private final Xsibion plugin;

    public FeatherfallSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.FEATHERFALL;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // handled reactively in the damage listener
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        // nothing to clean up
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) {
            return;
        }
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getSkillLevel(SkillId.FEATHERFALL.key());
        if (level <= 0 || !data.isSkillToggledOn(SkillId.FEATHERFALL.key())) {
            return;
        }
        SkillLevelDefinition levelDef = plugin.getSkillManager().getDefinition(SkillId.FEATHERFALL).getLevel(level);
        double percent = levelDef.getDouble("fall-damage-reduction-percent", 0);
        double multiplier = Math.max(0, 1.0 - (percent / 100.0));
        double newDamage = event.getDamage() * multiplier;
        if (newDamage <= 0.01) {
            event.setCancelled(true);
        } else {
            event.setDamage(newDamage);
        }
    }
}
