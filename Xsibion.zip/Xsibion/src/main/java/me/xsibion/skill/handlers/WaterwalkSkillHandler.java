package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Waterwalk: while toggled ON, the player does not sink when standing on open water.
 */
public class WaterwalkSkillHandler implements SkillHandler {

    private final Xsibion plugin;
    private final Map<UUID, BukkitTask> tasks = new ConcurrentHashMap<>();

    public WaterwalkSkillHandler(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public SkillId getId() {
        return SkillId.WATERWALK;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        stop(player.getUniqueId());
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || player.isDead()) {
                return;
            }
            PlayerData current = plugin.getPlayerDataManager().get(player);
            if (!current.isSkillToggledOn(SkillId.WATERWALK.key())) {
                stop(player.getUniqueId());
                return;
            }
            if (player.isSneaking()) {
                return; // allow the player to sneak to dive if they want to
            }
            Block feet = player.getLocation().getBlock();
            Block below = feet.getRelative(0, -1, 0);
            boolean standingOnWaterSurface = below.getType() == Material.WATER && feet.getType() != Material.WATER;
            boolean sinkingIntoWater = feet.getType() == Material.WATER;
            if (standingOnWaterSurface || sinkingIntoWater) {
                Vector velocity = player.getVelocity();
                if (velocity.getY() < 0) {
                    player.setVelocity(new Vector(velocity.getX(), 0, velocity.getZ()));
                }
                player.setFallDistance(0f);
                if (sinkingIntoWater) {
                    player.teleport(player.getLocation().add(0, 0.35, 0));
                }
            }
        }, 2L, 2L);
        tasks.put(player.getUniqueId(), task);
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        stop(player.getUniqueId());
    }

    private void stop(UUID uuid) {
        BukkitTask task = tasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }
    }
}
