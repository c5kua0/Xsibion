package me.xsibion.skill;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The tier-scaled stats for one level (1-3) of one skill, loaded straight
 * from config.yml. Generic numeric/material fields cover every skill's needs
 * so no per-skill subclassing is required.
 */
public class SkillLevelDefinition {

    private final int level;
    private final String displaySuffix;
    private final double unlockCostArcana;
    private final Map<Material, Integer> unlockMaterials;
    private final ConfigurationSection raw;

    public SkillLevelDefinition(int level, ConfigurationSection section) {
        this.level = level;
        this.raw = section;
        this.displaySuffix = section.getString("display-suffix", String.valueOf(level));
        this.unlockCostArcana = section.getDouble("unlock-cost-arcana", 0);
        this.unlockMaterials = new LinkedHashMap<>();
        if (section.isConfigurationSection("unlock-materials")) {
            for (String matKey : section.getConfigurationSection("unlock-materials").getKeys(false)) {
                Material material = Material.matchMaterial(matKey);
                if (material != null) {
                    unlockMaterials.put(material, section.getInt("unlock-materials." + matKey));
                }
            }
        }
    }

    public int getLevel() {
        return level;
    }

    public String getDisplaySuffix() {
        return displaySuffix;
    }

    public double getUnlockCostArcana() {
        return unlockCostArcana;
    }

    public Map<Material, Integer> getUnlockMaterials() {
        return unlockMaterials;
    }

    public double getDouble(String path, double def) {
        return raw.getDouble(path, def);
    }

    public int getInt(String path, int def) {
        return raw.getInt(path, def);
    }

    public boolean getBoolean(String path, boolean def) {
        return raw.getBoolean(path, def);
    }
}
