package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillLevelDefinition;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Base class for skills that are just "apply a potion effect while toggled ON,
 * remove it when toggled OFF", with the amplifier read from config.
 */
public abstract class PotionToggleSkillHandler implements SkillHandler {

    protected final Xsibion plugin;
    private final PotionEffectType effectType;
    private final String amplifierConfigKey;

    protected PotionToggleSkillHandler(Xsibion plugin, PotionEffectType effectType, String amplifierConfigKey) {
        this.plugin = plugin;
        this.effectType = effectType;
        this.amplifierConfigKey = amplifierConfigKey;
    }

    @Override
    public void onToggleOn(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        int amplifier = levelDef.getInt(amplifierConfigKey, 0);
        // Practically infinite duration; refreshed every time the skill is toggled or the plugin restarts.
        player.addPotionEffect(new PotionEffect(effectType, Integer.MAX_VALUE, amplifier, false, false, true));
    }

    @Override
    public void onToggleOff(Player player, PlayerData data, SkillLevelDefinition levelDef) {
        player.removePotionEffect(effectType);
    }
}
