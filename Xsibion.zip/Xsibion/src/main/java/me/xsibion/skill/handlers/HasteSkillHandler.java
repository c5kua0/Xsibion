package me.xsibion.skill.handlers;

import me.xsibion.Xsibion;
import me.xsibion.skill.SkillId;
import org.bukkit.potion.PotionEffectType;

/**
 * Haste: increases mining speed via a Haste effect.
 */
public class HasteSkillHandler extends PotionToggleSkillHandler {

    public HasteSkillHandler(Xsibion plugin) {
        super(plugin, PotionEffectType.HASTE, "haste-amplifier");
    }

    @Override
    public SkillId getId() {
        return SkillId.HASTE;
    }
}
