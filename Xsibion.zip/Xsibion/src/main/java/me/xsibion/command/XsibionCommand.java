package me.xsibion.command;

import me.xsibion.Xsibion;
import me.xsibion.gui.MainMenuGUI;
import me.xsibion.util.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /xsibion - opens the main menu for any player. No permission required.
 */
public class XsibionCommand implements CommandExecutor {

    private final Xsibion plugin;

    public XsibionCommand(Xsibion plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            MessageUtil.send(sender, "&cOnly players can use /xsibion.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload") && sender.isOp()) {
            plugin.reloadXsibionConfig();
            MessageUtil.send(sender, "&aXsibion configuration reloaded.");
            return true;
        }
        MainMenuGUI.open(plugin, (Player) sender);
        return true;
    }
}
