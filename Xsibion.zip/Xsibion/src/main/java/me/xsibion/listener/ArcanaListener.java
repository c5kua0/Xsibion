package me.xsibion.listener;

import me.xsibion.Xsibion;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wither;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.inventory.MerchantInventory;

/**
 * Awards Arcana for the configured gameplay sources: hostile/passive mob
 * kills, boss kills, villager trades, advancements, and ore mining.
 * Xsibion quests can also award Arcana via ArcanaManager#getQuestReward()
 * once a quest system is wired up to call it.
 */
public class ArcanaListener implements Listener {

    private final Xsibion plugin;

    public ArcanaListener(Xsibion plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        Player killer = entity.getKiller();
        if (killer == null) {
            return;
        }

        boolean isBoss = entity instanceof EnderDragon || entity instanceof Wither
                || entity.getType().name().equals("ELDER_GUARDIAN") || entity.getType().name().equals("WARDEN");

        double reward;
        if (isBoss) {
            reward = plugin.getArcanaManager().getBossKillReward();
        } else if (entity instanceof Monster) {
            reward = plugin.getArcanaManager().getHostileMobKillReward();
        } else if (entity instanceof Player) {
            return; // PvP kills do not award Arcana
        } else {
            reward = plugin.getArcanaManager().getPassiveMobKillReward();
        }

        plugin.getArcanaManager().grant(killer, reward);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAdvancement(PlayerAdvancementDoneEvent event) {
        // Skip the "recipe unlocked" pseudo-advancements which fire constantly and are not real achievements.
        if (event.getAdvancement().getKey().getKey().startsWith("recipes/")) {
            return;
        }
        plugin.getArcanaManager().grant(event.getPlayer(), plugin.getArcanaManager().getAdvancementReward());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getArcanaManager().isOreRewarded(event.getBlock().getType())) {
            return;
        }
        double reward = plugin.getArcanaManager().getOreReward(event.getBlock().getType());
        plugin.getArcanaManager().grant(player, reward);
    }

    /**
     * Villager trades have no dedicated Bukkit "trade completed" event, so a
     * completed trade is detected by watching for a click on the merchant
     * result slot (slot 2) of a MerchantInventory that isn't cancelled.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMerchantClick(InventoryClickEvent event) {
        if (!(event.getInventory() instanceof MerchantInventory)) {
            return;
        }
        if (event.getRawSlot() != 2) {
            return;
        }
        if (event.getCurrentItem() == null || event.getCurrentItem().getType() == org.bukkit.Material.AIR) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Player trader = (Player) event.getWhoClicked();
        plugin.getArcanaManager().grant(trader, plugin.getArcanaManager().getVillagerTradeReward());
    }
}
