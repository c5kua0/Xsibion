package me.xsibion.listener;

import me.xsibion.Xsibion;
import me.xsibion.skill.SkillId;
import me.xsibion.util.BlockInteractionUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Mobile / Bedrock-Geyser friendly skill toggle: hold the skill item in its
 * assigned hotbar slot and Shift + Right Click to flip it OFF -&gt; ON -&gt; OFF.
 * No keyboard-only controls (Q key, number keys) are used anywhere.
 */
public class SkillToggleListener implements Listener {

    private final Xsibion plugin;

    public SkillToggleListener(Xsibion plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return; // avoid double-firing for the off-hand
        }
        switch (event.getAction()) {
            case RIGHT_CLICK_AIR:
            case RIGHT_CLICK_BLOCK:
                break;
            default:
                return;
        }

        Player player = event.getPlayer();
        ItemStack held = event.getItem();
        SkillId id = plugin.getSkillManager().getSkillFromItem(held);
        if (id == null) {
            return;
        }

        // Prevent the raw item (a fire charge, feather, etc.) from placing
        // blocks, opening containers unexpectedly, or triggering vanilla use.
        if (event.getClickedBlock() != null && BlockInteractionUtil.isInteractable(event.getClickedBlock().getType())) {
            return; // let the player interact with the chest/door/etc. normally
        }
        event.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
        event.setUseInteractedBlock(org.bukkit.event.Event.Result.DENY);

        if (!player.isSneaking()) {
            return; // plain right click is left for skill-specific casts (e.g. Fireball)
        }

        plugin.getSkillManager().toggleSkill(player, id);
    }
}
