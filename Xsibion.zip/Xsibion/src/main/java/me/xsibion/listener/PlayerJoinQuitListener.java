package me.xsibion.listener;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillDefinition;
import me.xsibion.skill.SkillHandler;
import me.xsibion.skill.SkillId;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Loads player data (lazily, on first access) and reapplies any running
 * skill/Magic Item effects on join - since potion effects and scheduled
 * tasks do not survive a relog or server restart, only the underlying
 * toggle/equip state does. On quit, everything is saved and cleanly torn
 * down so no per-player tasks or listeners leak.
 */
public class PlayerJoinQuitListener implements Listener {

    private final Xsibion plugin;

    public PlayerJoinQuitListener(Xsibion plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);

        // restore equipped skill items into their hotbar slots
        for (SkillId id : SkillId.values()) {
            int slot = data.getEquippedSlot(id.key());
            if (slot >= 0 && data.getSkillLevel(id.key()) > 0) {
                plugin.getSkillManager().giveSkillItem(player, id, slot);
                if (data.isSkillToggledOn(id.key())) {
                    SkillDefinition def = plugin.getSkillManager().getDefinition(id);
                    SkillHandler handler = plugin.getSkillManager().getHandler(id);
                    if (def != null && handler != null) {
                        handler.onToggleOn(player, data, def.getLevel(data.getSkillLevel(id.key())));
                    }
                }
            }
        }

        plugin.getMagicItemManager().reapplyEquippedEffects(player);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getSkillManager().disableAllOnQuit(player);
        plugin.getMagicItemManager().disableAllOnQuit(player);
        plugin.getPlayerDataManager().save(player.getUniqueId());
        plugin.getPlayerDataManager().unload(player.getUniqueId());
    }
}
