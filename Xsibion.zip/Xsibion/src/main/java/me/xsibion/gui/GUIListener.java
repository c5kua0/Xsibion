package me.xsibion.gui;

import me.xsibion.Xsibion;
import me.xsibion.crafting.CraftingRecipe;
import me.xsibion.item.MagicItemId;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillId;
import me.xsibion.util.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.Listener;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

/**
 * Central click/drag/close handler for every Xsibion GUI. Read-only menus
 * (main menu, skill/item lists & details) cancel every click and route
 * navigation off the clicked slot. The Crafting GUI is the one screen that
 * allows real item placement, restricted to its 3x3 grid, with full
 * anti-exploit protections (no taking filler/result/button items, no drag
 * outside the grid, ingredients returned on close).
 */
public class GUIListener implements Listener {

    private final Xsibion plugin;

    public GUIListener(Xsibion plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof GuiHolder)) {
            return;
        }
        GuiHolder holder = (GuiHolder) rawHolder;
        Player player = (Player) event.getWhoClicked();

        if (holder.getType() == GuiType.CRAFTING) {
            handleCraftingClick(event, player, holder);
            return;
        }

        // every other Xsibion GUI is a read-only navigation menu
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }
        int slot = event.getSlot();

        switch (holder.getType()) {
            case MAIN_MENU:
                handleMainMenuClick(player, slot);
                break;
            case SKILL_LIST:
                handleSkillListClick(player, slot);
                break;
            case SKILL_DETAIL:
                handleSkillDetailClick(player, slot, SkillId.fromKey(holder.getContextId()));
                break;
            case ITEM_LIST:
                handleItemListClick(player, slot);
                break;
            case ITEM_DETAIL:
                handleItemDetailClick(player, slot, MagicItemId.fromKey(holder.getContextId()));
                break;
            default:
                break;
        }
    }

    private void handleMainMenuClick(Player player, int slot) {
        switch (slot) {
            case 11:
                SkillGUI.openList(plugin, player);
                break;
            case 13:
                MagicItemGUI.openList(plugin, player);
                break;
            case 15:
                CraftingGUI.open(plugin, player);
                break;
            default:
                break;
        }
    }

    private void handleSkillListClick(Player player, int slot) {
        if (slot == 40) {
            MainMenuGUI.open(plugin, player);
            return;
        }
        if (slot == 8) {
            buySkillSlot(player);
            SkillGUI.openList(plugin, player);
            return;
        }
        int[] listSlots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};
        SkillId[] ids = SkillId.values();
        for (int i = 0; i < listSlots.length && i < ids.length; i++) {
            if (listSlots[i] == slot) {
                SkillGUI.openDetail(plugin, player, ids[i]);
                return;
            }
        }
    }

    private void handleSkillDetailClick(Player player, int slot, SkillId id) {
        if (id == null) {
            return;
        }
        switch (slot) {
            case 22:
                SkillGUI.openList(plugin, player);
                return;
            case 11:
                plugin.getSkillManager().unlockNextLevel(player, id);
                SkillGUI.openDetail(plugin, player, id);
                return;
            case 13: {
                PlayerData data = plugin.getPlayerDataManager().get(player);
                if (data.getSkillLevel(id.key()) > 0) {
                    plugin.getSkillManager().toggleSkill(player, id);
                }
                SkillGUI.openDetail(plugin, player, id);
                return;
            }
            case 15:
                handleEquipToggle(player, id);
                SkillGUI.openDetail(plugin, player, id);
                return;
            default:
        }
    }

    private void handleEquipToggle(Player player, SkillId id) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.getSkillLevel(id.key()) <= 0) {
            return;
        }
        int currentSlot = data.getEquippedSlot(id.key());
        if (currentSlot >= 0) {
            plugin.getSkillManager().unequipSkill(player, id);
            return;
        }
        int equippedCount = (int) data.getEquippedSkillSlots().values().stream().filter(v -> v >= 0).count();
        if (equippedCount >= plugin.getSkillManager().getMaxSkillSlots(data)) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.no-free-skill-slot"));
            return;
        }
        int freeHotbarSlot = -1;
        for (int i = 0; i < 9; i++) {
            if (data.getSkillEquippedInSlot(i) != null) {
                continue;
            }
            ItemStack existing = player.getInventory().getItem(i);
            if (existing == null || existing.getType() == org.bukkit.Material.AIR) {
                freeHotbarSlot = i;
                break;
            }
        }
        if (freeHotbarSlot == -1) {
            MessageUtil.send(player, "&cYour hotbar has no empty slot to equip this skill into.");
            return;
        }
        plugin.getSkillManager().equipSkill(player, id, freeHotbarSlot);
    }

    private void buySkillSlot(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int current = plugin.getConfig().getInt("skill-slots.default", 5) + data.getPurchasedSkillSlots();
        int max = plugin.getConfig().getInt("skill-slots.maximum", 9);
        if (current >= max) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.max-slots-reached"));
            return;
        }
        double cost = plugin.getConfig().getDouble("skill-slots.purchase-cost." + (current + 1), 0);
        if (data.getArcana() < cost) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.not-enough-arcana"));
            return;
        }
        data.spendArcana(cost);
        data.setPurchasedSkillSlots(data.getPurchasedSkillSlots() + 1);
        MessageUtil.send(player, plugin.getConfig().getString("messages.slot-purchased"));
    }

    private void buyMagicItemSlot(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int current = plugin.getConfig().getInt("magic-item-slots.default", 3) + data.getPurchasedMagicItemSlots();
        int max = plugin.getConfig().getInt("magic-item-slots.maximum", 7);
        if (current >= max) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.max-slots-reached"));
            return;
        }
        double cost = plugin.getConfig().getDouble("magic-item-slots.purchase-cost." + (current + 1), 0);
        if (data.getArcana() < cost) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.not-enough-arcana"));
            return;
        }
        data.spendArcana(cost);
        data.setPurchasedMagicItemSlots(data.getPurchasedMagicItemSlots() + 1);
        MessageUtil.send(player, plugin.getConfig().getString("messages.slot-purchased"));
    }

    private void handleItemListClick(Player player, int slot) {
        if (slot == 40) {
            MainMenuGUI.open(plugin, player);
            return;
        }
        if (slot == 8) {
            buyMagicItemSlot(player);
            MagicItemGUI.openList(plugin, player);
            return;
        }
        int[] listSlots = {10, 11, 12, 13, 14, 15, 16};
        MagicItemId[] ids = MagicItemId.values();
        for (int i = 0; i < listSlots.length && i < ids.length; i++) {
            if (listSlots[i] == slot) {
                MagicItemGUI.openDetail(plugin, player, ids[i]);
                return;
            }
        }
    }

    private void handleItemDetailClick(Player player, int slot, MagicItemId id) {
        if (id == null) {
            return;
        }
        switch (slot) {
            case 22:
                MagicItemGUI.openList(plugin, player);
                return;
            case 11:
                plugin.getMagicItemManager().unlockNextLevel(player, id);
                MagicItemGUI.openDetail(plugin, player, id);
                return;
            case 15:
                plugin.getMagicItemManager().toggleEquip(player, id);
                MagicItemGUI.openDetail(plugin, player, id);
                return;
            default:
        }
    }

    // ---------------- Crafting GUI ----------------

    private void handleCraftingClick(InventoryClickEvent event, Player player, GuiHolder holder) {
        Inventory top = event.getView().getTopInventory();
        int rawSlot = event.getRawSlot();
        boolean clickedTop = rawSlot >= 0 && rawSlot < top.getSize();

        // Double-click "collect similar items" can pull matching stacks from
        // anywhere the player can see, including protected slots - block it outright.
        if (event.getClick() == ClickType.DOUBLE_CLICK) {
            event.setCancelled(true);
            return;
        }

        if (clickedTop) {
            if (rawSlot == CraftingGUI.BACK_BUTTON_SLOT) {
                event.setCancelled(true);
                CraftingGUI.returnGridItems(player, top);
                MainMenuGUI.open(plugin, player);
                return;
            }
            if (rawSlot == CraftingGUI.CRAFT_BUTTON_SLOT) {
                event.setCancelled(true);
                attemptCraft(player, top);
                return;
            }
            if (rawSlot == CraftingGUI.RESULT_SLOT) {
                event.setCancelled(true);
                return;
            }
            if (!CraftingGUI.isGridSlot(rawSlot)) {
                event.setCancelled(true);
                return;
            }
            // grid slot: allow normal pickup/place/swap to proceed
        } else {
            // clicked in the player's own inventory
            if (event.isShiftClick()) {
                event.setCancelled(true);
                moveOneStackIntoGrid(player, top, event.getCurrentItem());
                return;
            }
        }

        plugin.getServer().getScheduler().runTask(plugin, () -> CraftingGUI.refresh(plugin, player, top));
    }

    private void moveOneStackIntoGrid(Player player, Inventory top, ItemStack clicked) {
        if (clicked == null || clicked.getType() == org.bukkit.Material.AIR) {
            return;
        }
        for (int slot : CraftingGUI.GRID_SLOTS) {
            ItemStack existing = top.getItem(slot);
            if (existing == null || existing.getType() == org.bukkit.Material.AIR) {
                ItemStack moved = clicked.clone();
                top.setItem(slot, moved);
                int sourceSlot = player.getInventory().first(clicked);
                if (sourceSlot >= 0) {
                    player.getInventory().setItem(sourceSlot, null);
                }
                break;
            }
        }
        plugin.getServer().getScheduler().runTask(plugin, () -> CraftingGUI.refresh(plugin, player, top));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof GuiHolder)) {
            return;
        }
        GuiHolder holder = (GuiHolder) rawHolder;
        if (holder.getType() != GuiType.CRAFTING) {
            event.setCancelled(true);
            return;
        }
        int topSize = event.getView().getTopInventory().getSize();
        for (int rawSlot : event.getRawSlots()) {
            if (rawSlot < topSize && !CraftingGUI.isGridSlot(rawSlot)) {
                event.setCancelled(true);
                return;
            }
        }
        Player player = (Player) event.getWhoClicked();
        plugin.getServer().getScheduler().runTask(plugin, () -> CraftingGUI.refresh(plugin, player, event.getView().getTopInventory()));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof GuiHolder)) {
            return;
        }
        GuiHolder holder = (GuiHolder) rawHolder;
        if (holder.getType() == GuiType.CRAFTING && event.getPlayer() instanceof Player) {
            CraftingGUI.returnGridItems((Player) event.getPlayer(), event.getInventory());
        }
    }

    private void attemptCraft(Player player, Inventory top) {
        ItemStack[] grid = new ItemStack[CraftingGUI.GRID_SLOTS.length];
        for (int i = 0; i < CraftingGUI.GRID_SLOTS.length; i++) {
            grid[i] = top.getItem(CraftingGUI.GRID_SLOTS[i]);
        }
        CraftingRecipe recipe = plugin.getCraftingManager().findMatch(grid);
        if (recipe == null) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.craft-missing-ingredients"));
            return;
        }

        PlayerData data = plugin.getPlayerDataManager().get(player);
        boolean meetsRequirement;
        if (recipe.getResultType() == CraftingRecipe.ResultType.SKILL) {
            SkillId skillId = SkillId.fromKey(recipe.getResultId());
            meetsRequirement = skillId != null && data.getSkillLevel(skillId.key()) == recipe.getRequiresCurrentLevel();
        } else {
            MagicItemId itemId = MagicItemId.fromKey(recipe.getResultId());
            meetsRequirement = itemId != null && data.getMagicItemLevel(itemId.key()) == recipe.getRequiresCurrentLevel();
        }
        if (!meetsRequirement) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.craft-missing-requirement"));
            return;
        }
        if (data.getArcana() < recipe.getArcanaCost()) {
            MessageUtil.send(player, plugin.getConfig().getString("messages.not-enough-arcana"));
            return;
        }

        // consume grid ingredients
        for (int slot : CraftingGUI.GRID_SLOTS) {
            top.setItem(slot, null);
        }
        data.spendArcana(recipe.getArcanaCost());

        String resultName;
        if (recipe.getResultType() == CraftingRecipe.ResultType.SKILL) {
            SkillId skillId = SkillId.fromKey(recipe.getResultId());
            data.setSkillLevel(skillId.key(), recipe.getResultLevel());
            resultName = plugin.getSkillManager().getDefinition(skillId).getDisplayName() + " Level " + recipe.getResultLevel();
            int equippedSlot = data.getEquippedSlot(skillId.key());
            if (equippedSlot >= 0) {
                plugin.getSkillManager().giveSkillItem(player, skillId, equippedSlot);
            }
        } else {
            MagicItemId itemId = MagicItemId.fromKey(recipe.getResultId());
            data.setMagicItemLevel(itemId.key(), recipe.getResultLevel());
            resultName = plugin.getMagicItemManager().getDefinition(itemId).getDisplayName() + " Level " + recipe.getResultLevel();
            if (data.isMagicItemEquipped(itemId.key())) {
                me.xsibion.item.MagicItemHandler handler = plugin.getMagicItemManager().getHandler(itemId);
                me.xsibion.item.MagicItemDefinition def = plugin.getMagicItemManager().getDefinition(itemId);
                if (handler != null && def != null) {
                    handler.onUnequip(player, data, def.getLevel(recipe.getRequiresCurrentLevel()));
                    handler.onEquip(player, data, def.getLevel(recipe.getResultLevel()));
                }
            }
        }

        String msg = plugin.getConfig().getString("messages.craft-success", "");
        msg = MessageUtil.replace(msg, "%result%", resultName);
        MessageUtil.send(player, msg);
        player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);

        CraftingGUI.refresh(plugin, player, top);
    }
}
