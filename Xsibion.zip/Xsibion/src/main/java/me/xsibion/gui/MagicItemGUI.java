package me.xsibion.gui;

import me.xsibion.Xsibion;
import me.xsibion.item.MagicItemDefinition;
import me.xsibion.item.MagicItemId;
import me.xsibion.item.MagicItemLevelDefinition;
import me.xsibion.player.PlayerData;
import me.xsibion.util.ItemBuilder;
import me.xsibion.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Magic Item list + detail GUIs.
 */
public final class MagicItemGUI {

    private static final int[] LIST_SLOTS = {10, 11, 12, 13, 14, 15, 16};

    private MagicItemGUI() {
    }

    public static void openList(Xsibion plugin, Player player) {
        GuiHolder holder = new GuiHolder(GuiType.ITEM_LIST, null);
        String title = MessageUtil.color(plugin.getConfig().getString("gui.item-menu-title", "&5Magic Items"));
        Inventory inventory = Bukkit.createInventory(holder, 45, title);
        holder.setInventory(inventory);

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }

        PlayerData data = plugin.getPlayerDataManager().get(player);
        MagicItemId[] ids = MagicItemId.values();
        for (int i = 0; i < ids.length && i < LIST_SLOTS.length; i++) {
            MagicItemId id = ids[i];
            MagicItemDefinition def = plugin.getMagicItemManager().getDefinition(id);
            if (def == null) {
                continue;
            }
            inventory.setItem(LIST_SLOTS[i], buildListIcon(data, def));
        }

        inventory.setItem(4, new ItemBuilder(Material.NETHER_STAR)
                .name("&d&l\uD83D\uDD2E Arcana: &f" + MainMenuGUI.formatArcana(data.getArcana()))
                .build());
        inventory.setItem(8, buildBuySlotIcon(plugin, data));
        inventory.setItem(40, new ItemBuilder(Material.ARROW).name("&c&lBack").build());

        player.openInventory(inventory);
    }

    private static ItemStack buildBuySlotIcon(Xsibion plugin, PlayerData data) {
        int current = plugin.getConfig().getInt("magic-item-slots.default", 3) + data.getPurchasedMagicItemSlots();
        int max = plugin.getConfig().getInt("magic-item-slots.maximum", 7);
        List<String> lore = new ArrayList<>();
        lore.add("&7Current Magic Item Slots: &f" + current + "/" + max);
        if (current >= max) {
            lore.add("&cMaximum slots reached.");
        } else {
            double cost = plugin.getConfig().getDouble("magic-item-slots.purchase-cost." + (current + 1), 0);
            lore.add("&7Cost for slot #" + (current + 1) + ": &d" + MainMenuGUI.formatArcana(cost));
            lore.add("");
            lore.add(data.getArcana() >= cost ? "&e&lClick to purchase" : "&c&lNot enough Arcana");
        }
        return new ItemBuilder(Material.CHEST)
                .name("&6&lBuy Magic Item Slot")
                .lore(lore)
                .build();
    }

    private static ItemStack buildListIcon(PlayerData data, MagicItemDefinition def) {
        int level = data.getMagicItemLevel(def.getId().key());
        boolean unlocked = level > 0;
        boolean equipped = data.isMagicItemEquipped(def.getId().key());

        List<String> lore = new ArrayList<>();
        lore.add("&7" + def.getDescription());
        lore.add("");
        lore.add(unlocked ? "&aUnlocked &7(Level " + level + "/" + def.getMaxLevel() + ")" : "&cLocked");
        if (unlocked) {
            lore.add("&7Equipped: " + (equipped ? "&a&lYES" : "&c&lNO"));
        }
        lore.add("");
        lore.add("&eClick to view details");

        return new ItemBuilder(def.getIcon())
                .name((unlocked ? "&d&l" : "&7&l") + def.getDisplayName())
                .lore(lore)
                .build();
    }

    public static void openDetail(Xsibion plugin, Player player, MagicItemId id) {
        MagicItemDefinition def = plugin.getMagicItemManager().getDefinition(id);
        if (def == null) {
            return;
        }
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getMagicItemLevel(id.key());
        boolean unlocked = level > 0;

        GuiHolder holder = new GuiHolder(GuiType.ITEM_DETAIL, id.key());
        Inventory inventory = Bukkit.createInventory(holder, 27, MessageUtil.color("&5&l" + def.getDisplayName()));
        holder.setInventory(inventory);

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }

        List<String> infoLore = new ArrayList<>();
        infoLore.add("&7" + def.getDescription());
        infoLore.add("");
        infoLore.add("&7Tier: " + tierLabel(Math.max(1, level)));
        infoLore.add("&7Level: &f" + level + "/" + def.getMaxLevel());
        infoLore.add("&7Status: " + (unlocked ? "&aUnlocked" : "&cLocked"));
        if (unlocked) {
            infoLore.add("&7Equipped: " + (data.isMagicItemEquipped(id.key()) ? "&a&lYES" : "&c&lNO"));
        }
        inventory.setItem(4, new ItemBuilder(def.getIcon()).name("&d&l" + def.getDisplayName()).lore(infoLore).build());

        if (def.hasLevel(level + 1)) {
            MagicItemLevelDefinition next = def.getLevel(level + 1);
            List<String> upgradeLore = new ArrayList<>();
            upgradeLore.add(level == 0 ? "&7Unlock this Magic Item." : "&7Upgrade to level " + (level + 1) + ".");
            upgradeLore.add("");
            upgradeLore.add("&7Cost: &d" + MainMenuGUI.formatArcana(next.getUnlockCostArcana()) + " Arcana");
            for (Map.Entry<org.bukkit.Material, Integer> entry : next.getUnlockMaterials().entrySet()) {
                boolean has = player.getInventory().containsAtLeast(new ItemStack(entry.getKey()), entry.getValue());
                upgradeLore.add((has ? "&a" : "&c") + entry.getValue() + "x " + prettyName(entry.getKey().name()));
            }
            upgradeLore.add("");
            upgradeLore.add(plugin.getMagicItemManager().canAffordNextLevel(player, id) ? "&e&lClick to " + (level == 0 ? "unlock" : "upgrade") : "&c&lRequirements not met");

            inventory.setItem(11, new ItemBuilder(level == 0 ? Material.LIME_DYE : Material.EXPERIENCE_BOTTLE)
                    .name(level == 0 ? "&a&lUnlock" : "&a&lUpgrade")
                    .lore(upgradeLore)
                    .build());
        } else if (unlocked) {
            inventory.setItem(11, new ItemBuilder(Material.BEACON)
                    .name("&6&lMax Level Reached")
                    .lore(List.of("&7This Magic Item is fully upgraded."))
                    .build());
        }

        if (unlocked) {
            boolean equipped = data.isMagicItemEquipped(id.key());
            inventory.setItem(15, new ItemBuilder(equipped ? Material.REDSTONE : Material.EMERALD)
                    .name(equipped ? "&c&lUnequip" : "&a&lEquip")
                    .lore(List.of("&7Magic Item Slots: &f" + data.getEquippedMagicItemCount() + "/" + plugin.getMagicItemManager().getMaxItemSlots(data)))
                    .build());
        }

        inventory.setItem(22, new ItemBuilder(Material.ARROW).name("&c&lBack").build());

        player.openInventory(inventory);
    }

    private static String tierLabel(int level) {
        switch (level) {
            case 1: return "&a\uD83D\uDFE2 Early Game";
            case 2: return "&b\uD83D\uDD35 Mid Game";
            case 3: return "&c\uD83D\uDD34 Late Game";
            default: return "&7Unknown";
        }
    }

    private static String prettyName(String enumName) {
        String[] parts = enumName.split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(part.charAt(0)).append(part.substring(1).toLowerCase());
        }
        return sb.toString();
    }
}
