package me.xsibion.gui;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.util.ItemBuilder;
import me.xsibion.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * The /xsibion main menu: Skills, Magic Items, Crafting, and the player's Arcana balance.
 */
public final class MainMenuGUI {

    private MainMenuGUI() {
    }

    public static void open(Xsibion plugin, Player player) {
        GuiHolder holder = new GuiHolder(GuiType.MAIN_MENU, null);
        String title = MessageUtil.color(plugin.getConfig().getString("gui.main-menu-title", "&5Xsibion"));
        Inventory inventory = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inventory);

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }

        PlayerData data = plugin.getPlayerDataManager().get(player);

        inventory.setItem(4, new ItemBuilder(Material.NETHER_STAR)
                .name("&d&l\uD83D\uDD2E Arcana")
                .lore(List.of("&7Your current Arcana balance:", "&d" + formatArcana(data.getArcana())))
                .build());

        inventory.setItem(11, new ItemBuilder(Material.BLAZE_ROD)
                .name("&b&lSkills")
                .lore(List.of("&7View, unlock, upgrade,", "&7equip and toggle your Skills.", "", "&eClick to open"))
                .build());

        inventory.setItem(13, new ItemBuilder(Material.TOTEM_OF_UNDYING)
                .name("&d&lMagic Items")
                .lore(List.of("&7View, unlock, upgrade,", "&7and equip your Magic Items.", "", "&eClick to open"))
                .build());

        inventory.setItem(15, new ItemBuilder(Material.CRAFTING_TABLE)
                .name("&6&lCrafting")
                .lore(List.of("&7Craft Xsibion materials into", "&7Skill and Magic Item upgrades.", "", "&eClick to open"))
                .build());

        player.openInventory(inventory);
    }

    public static String formatArcana(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.1f", amount);
    }
}
