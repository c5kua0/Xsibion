package me.xsibion.gui;

import me.xsibion.Xsibion;
import me.xsibion.player.PlayerData;
import me.xsibion.skill.SkillDefinition;
import me.xsibion.skill.SkillId;
import me.xsibion.skill.SkillLevelDefinition;
import me.xsibion.util.ItemBuilder;
import me.xsibion.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Skill list + skill detail GUIs.
 */
public final class SkillGUI {

    private static final int[] LIST_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};

    private SkillGUI() {
    }

    public static void openList(Xsibion plugin, Player player) {
        GuiHolder holder = new GuiHolder(GuiType.SKILL_LIST, null);
        String title = MessageUtil.color(plugin.getConfig().getString("gui.skill-menu-title", "&5Skills"));
        Inventory inventory = Bukkit.createInventory(holder, 45, title);
        holder.setInventory(inventory);

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }

        PlayerData data = plugin.getPlayerDataManager().get(player);
        SkillId[] ids = SkillId.values();
        for (int i = 0; i < ids.length && i < LIST_SLOTS.length; i++) {
            SkillId id = ids[i];
            SkillDefinition def = plugin.getSkillManager().getDefinition(id);
            if (def == null) {
                continue;
            }
            inventory.setItem(LIST_SLOTS[i], buildListIcon(plugin, data, def));
        }

        inventory.setItem(4, new ItemBuilder(Material.NETHER_STAR)
                .name("&d&l\uD83D\uDD2E Arcana: &f" + MainMenuGUI.formatArcana(data.getArcana()))
                .build());
        inventory.setItem(8, buildBuySlotIcon(plugin, data));
        inventory.setItem(40, new ItemBuilder(Material.ARROW).name("&c&lBack").build());

        player.openInventory(inventory);
    }

    private static ItemStack buildBuySlotIcon(Xsibion plugin, PlayerData data) {
        int current = plugin.getConfig().getInt("skill-slots.default", 5) + data.getPurchasedSkillSlots();
        int max = plugin.getConfig().getInt("skill-slots.maximum", 9);
        List<String> lore = new ArrayList<>();
        lore.add("&7Current Skill Slots: &f" + current + "/" + max);
        if (current >= max) {
            lore.add("&cMaximum slots reached.");
        } else {
            double cost = plugin.getConfig().getDouble("skill-slots.purchase-cost." + (current + 1), 0);
            lore.add("&7Cost for slot #" + (current + 1) + ": &d" + MainMenuGUI.formatArcana(cost));
            lore.add("");
            lore.add(data.getArcana() >= cost ? "&e&lClick to purchase" : "&c&lNot enough Arcana");
        }
        return new ItemBuilder(Material.CHEST)
                .name("&6&lBuy Skill Slot")
                .lore(lore)
                .build();
    }

    private static ItemStack buildListIcon(Xsibion plugin, PlayerData data, SkillDefinition def) {
        int level = data.getSkillLevel(def.getId().key());
        boolean unlocked = level > 0;
        boolean on = data.isSkillToggledOn(def.getId().key());
        int slot = data.getEquippedSlot(def.getId().key());

        List<String> lore = new ArrayList<>();
        lore.add("&7" + def.getDescription());
        lore.add("");
        lore.add(unlocked ? "&aUnlocked &7(Level " + level + "/" + def.getMaxLevel() + ")" : "&cLocked");
        if (unlocked) {
            lore.add(slot >= 0 ? "&7Equipped in hotbar slot &f" + (slot + 1) : "&7Not equipped");
            lore.add("&7State: " + (on ? "&a&lON" : "&c&lOFF"));
        }
        lore.add("");
        lore.add("&eClick to view details");

        return new ItemBuilder(def.getIcon())
                .name((unlocked ? "&b&l" : "&7&l") + def.getDisplayName())
                .lore(lore)
                .build();
    }

    public static void openDetail(Xsibion plugin, Player player, SkillId id) {
        SkillDefinition def = plugin.getSkillManager().getDefinition(id);
        if (def == null) {
            return;
        }
        PlayerData data = plugin.getPlayerDataManager().get(player);
        int level = data.getSkillLevel(id.key());
        boolean unlocked = level > 0;

        GuiHolder holder = new GuiHolder(GuiType.SKILL_DETAIL, id.key());
        Inventory inventory = Bukkit.createInventory(holder, 27,
                MessageUtil.color("&5&l" + def.getDisplayName()));
        holder.setInventory(inventory);

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }

        List<String> infoLore = new ArrayList<>();
        infoLore.add("&7" + def.getDescription());
        infoLore.add("");
        infoLore.add("&7Tier: " + tierLabel(Math.max(1, level)));
        infoLore.add("&7Level: &f" + level + "/" + def.getMaxLevel());
        infoLore.add("&7Status: " + (unlocked ? "&aUnlocked" : "&cLocked"));
        if (unlocked) {
            int slot = data.getEquippedSlot(id.key());
            infoLore.add("&7Equipped: " + (slot >= 0 ? "&aYes &7(slot " + (slot + 1) + ")" : "&cNo"));
            infoLore.add("&7Toggle: " + (data.isSkillToggledOn(id.key()) ? "&a&lON" : "&c&lOFF"));
        }
        inventory.setItem(4, new ItemBuilder(def.getIcon()).name("&b&l" + def.getDisplayName()).lore(infoLore).build());

        if (def.hasLevel(level + 1)) {
            SkillLevelDefinition next = def.getLevel(level + 1);
            List<String> upgradeLore = new ArrayList<>();
            upgradeLore.add(level == 0 ? "&7Unlock this skill." : "&7Upgrade to level " + (level + 1) + ".");
            upgradeLore.add("");
            upgradeLore.add("&7Cost: &d" + MainMenuGUI.formatArcana(next.getUnlockCostArcana()) + " Arcana");
            for (Map.Entry<org.bukkit.Material, Integer> entry : next.getUnlockMaterials().entrySet()) {
                boolean has = player.getInventory().containsAtLeast(new ItemStack(entry.getKey()), entry.getValue());
                upgradeLore.add((has ? "&a" : "&c") + entry.getValue() + "x " + prettyName(entry.getKey().name()));
            }
            upgradeLore.add("");
            upgradeLore.add(plugin.getSkillManager().canAffordNextLevel(player, id) ? "&e&lClick to " + (level == 0 ? "unlock" : "upgrade") : "&c&lRequirements not met");

            inventory.setItem(11, new ItemBuilder(level == 0 ? Material.LIME_DYE : Material.EXPERIENCE_BOTTLE)
                    .name(level == 0 ? "&a&lUnlock" : "&a&lUpgrade")
                    .lore(upgradeLore)
                    .build());
        } else if (unlocked) {
            inventory.setItem(11, new ItemBuilder(Material.BEACON)
                    .name("&6&lMax Level Reached")
                    .lore(List.of("&7This skill is fully upgraded."))
                    .build());
        }

        if (unlocked) {
            int slot = data.getEquippedSlot(id.key());
            boolean equipped = slot >= 0;
            inventory.setItem(15, new ItemBuilder(equipped ? Material.REDSTONE : Material.EMERALD)
                    .name(equipped ? "&c&lUnequip" : "&a&lEquip")
                    .lore(List.of(equipped
                            ? "&7Remove this skill from your hotbar."
                            : "&7Equip this skill to your hotbar.",
                            "", "&7Skill Slots: &f" + countEquipped(data) + "/" + plugin.getSkillManager().getMaxSkillSlots(data)))
                    .build());

            inventory.setItem(13, new ItemBuilder(data.isSkillToggledOn(id.key()) ? Material.REDSTONE_TORCH : Material.LEVER)
                    .name(data.isSkillToggledOn(id.key()) ? "&c&lToggle OFF" : "&a&lToggle ON")
                    .lore(List.of("&7You can also Shift + Right Click", "&7the skill item in your hotbar."))
                    .build());
        }

        inventory.setItem(22, new ItemBuilder(Material.ARROW).name("&c&lBack").build());

        player.openInventory(inventory);
    }

    private static int countEquipped(PlayerData data) {
        return (int) data.getEquippedSkillSlots().values().stream().filter(v -> v >= 0).count();
    }

    private static String tierLabel(int level) {
        switch (level) {
            case 1: return "&a\uD83D\uDFE2 Early Game";
            case 2: return "&b\uD83D\uDD35 Mid Game";
            case 3: return "&c\uD83D\uDD34 Late Game";
            default: return "&7Unknown";
        }
    }

    private static String prettyName(String enumName) {
        String[] parts = enumName.split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(part.charAt(0)).append(part.substring(1).toLowerCase());
        }
        return sb.toString();
    }
}
