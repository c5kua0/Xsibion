package me.xsibion.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Generic InventoryHolder marker used for every Xsibion GUI so the central
 * GUIListener can identify which screen a click happened in and, for detail
 * screens, which skill/item it refers to.
 */
public class GuiHolder implements InventoryHolder {

    private final GuiType type;
    private final String contextId;
    private Inventory inventory;

    public GuiHolder(GuiType type, String contextId) {
        this.type = type;
        this.contextId = contextId;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public GuiType getType() {
        return type;
    }

    public String getContextId() {
        return contextId;
    }
}
