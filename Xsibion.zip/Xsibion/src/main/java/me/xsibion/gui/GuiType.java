package me.xsibion.gui;

public enum GuiType {
    MAIN_MENU,
    SKILL_LIST,
    SKILL_DETAIL,
    ITEM_LIST,
    ITEM_DETAIL,
    CRAFTING
}
