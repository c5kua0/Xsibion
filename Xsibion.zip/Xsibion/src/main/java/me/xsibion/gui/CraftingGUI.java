package me.xsibion.gui;

import me.xsibion.Xsibion;
import me.xsibion.crafting.CraftingRecipe;
import me.xsibion.util.ItemBuilder;
import me.xsibion.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * The custom 3x3 Xsibion crafting GUI. Ingredients go in GRID_SLOTS, a live
 * preview + Arcana cost shows in RESULT_SLOT, and CRAFT_BUTTON_SLOT performs
 * the craft. Every other slot is a non-interactive filler pane.
 */
public final class CraftingGUI {

    public static final int[] GRID_SLOTS = {10, 11, 12, 19, 20, 21, 28, 29, 30};
    public static final int RESULT_SLOT = 24;
    public static final int CRAFT_BUTTON_SLOT = 40;
    public static final int BACK_BUTTON_SLOT = 49;
    public static final int SIZE = 54;

    private CraftingGUI() {
    }

    public static boolean isGridSlot(int slot) {
        for (int gridSlot : GRID_SLOTS) {
            if (gridSlot == slot) {
                return true;
            }
        }
        return false;
    }

    public static void open(Xsibion plugin, Player player) {
        GuiHolder holder = new GuiHolder(GuiType.CRAFTING, null);
        String title = MessageUtil.color(plugin.getConfig().getString("gui.crafting-menu-title", "&5Crafting"));
        Inventory inventory = Bukkit.createInventory(holder, SIZE, title);
        holder.setInventory(inventory);

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }
        for (int slot : GRID_SLOTS) {
            inventory.setItem(slot, null);
        }

        inventory.setItem(BACK_BUTTON_SLOT, new ItemBuilder(Material.ARROW).name("&c&lBack").build());
        refresh(plugin, player, inventory);

        player.openInventory(inventory);
    }

    /**
     * Recomputes the result preview / craft button based on the grid's current contents.
     */
    public static void refresh(Xsibion plugin, Player player, Inventory inventory) {
        ItemStack[] grid = new ItemStack[GRID_SLOTS.length];
        for (int i = 0; i < GRID_SLOTS.length; i++) {
            grid[i] = inventory.getItem(GRID_SLOTS[i]);
        }

        CraftingRecipe recipe = plugin.getCraftingManager().findMatch(grid);
        if (recipe == null) {
            inventory.setItem(RESULT_SLOT, new ItemBuilder(Material.BARRIER)
                    .name("&c&lNo Matching Recipe")
                    .lore(List.of("&7Place the exact ingredients", "&7for a valid Xsibion recipe."))
                    .build());
            inventory.setItem(CRAFT_BUTTON_SLOT, new ItemBuilder(Material.GRAY_DYE)
                    .name("&7Craft")
                    .lore(List.of("&cNo recipe matches your grid."))
                    .build());
            return;
        }

        boolean meetsRequirement;
        String resultName;
        if (recipe.getResultType() == CraftingRecipe.ResultType.SKILL) {
            var skillId = me.xsibion.skill.SkillId.fromKey(recipe.getResultId());
            var def = skillId != null ? plugin.getSkillManager().getDefinition(skillId) : null;
            int current = skillId != null ? plugin.getPlayerDataManager().get(player).getSkillLevel(skillId.key()) : -1;
            meetsRequirement = current == recipe.getRequiresCurrentLevel();
            resultName = (def != null ? def.getDisplayName() : recipe.getResultId()) + " Level " + recipe.getResultLevel();
        } else {
            var itemId = me.xsibion.item.MagicItemId.fromKey(recipe.getResultId());
            var def = itemId != null ? plugin.getMagicItemManager().getDefinition(itemId) : null;
            int current = itemId != null ? plugin.getPlayerDataManager().get(player).getMagicItemLevel(itemId.key()) : -1;
            meetsRequirement = current == recipe.getRequiresCurrentLevel();
            resultName = (def != null ? def.getDisplayName() : recipe.getResultId()) + " Level " + recipe.getResultLevel();
        }

        boolean hasArcana = plugin.getPlayerDataManager().get(player).getArcana() >= recipe.getArcanaCost();

        List<String> lore = new java.util.ArrayList<>();
        lore.add("&7Result: &f" + resultName);
        lore.add("&7Arcana Cost: " + (hasArcana ? "&a" : "&c") + MainMenuGUI.formatArcana(recipe.getArcanaCost()));
        if (!meetsRequirement) {
            lore.add("&cYou do not meet the level requirement for this recipe.");
        }
        inventory.setItem(RESULT_SLOT, new ItemBuilder(Material.ENCHANTED_BOOK)
                .name("&a&l" + resultName)
                .lore(lore)
                .build());

        boolean canCraft = meetsRequirement && hasArcana;
        inventory.setItem(CRAFT_BUTTON_SLOT, new ItemBuilder(canCraft ? Material.LIME_DYE : Material.GRAY_DYE)
                .name(canCraft ? "&a&lCraft!" : "&7Craft")
                .lore(List.of(canCraft ? "&eClick to craft this recipe." : "&cRequirements not met."))
                .build());
    }

    /**
     * Returns every non-empty grid ItemStack to the player's inventory (or drops
     * it at their feet if their inventory is full), then clears the grid slots.
     */
    public static void returnGridItems(Player player, Inventory inventory) {
        for (int slot : GRID_SLOTS) {
            ItemStack stack = inventory.getItem(slot);
            if (stack != null && stack.getType() != Material.AIR) {
                Map<Integer, ItemStack> leftovers = player.getInventory().addItem(stack);
                for (ItemStack leftover : leftovers.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), leftover);
                }
                inventory.setItem(slot, null);
            }
        }
    }
}
