# Xsibion

A complete custom Skills, Magic Items, Arcana currency and Xsibion crafting
plugin for Paper servers, built with pure Java + Maven. Every player can use
`/xsibion` — no permissions required.

## Features

- **Arcana** currency earned from hostile/passive mob kills, villager trades,
  advancements, ore mining, and boss kills. Fully persistent across relogs,
  restarts and plugin reloads.
- **10 Skills** (Fireball, Healing, Power Up, Quickstep, Iron Skin, Haste,
  Featherfall, Waterwalk, Arcane Focus, Arcane Shield), each with 3 tiers
  (🟢 Early / 🔵 Mid / 🔴 Late), unlocked and upgraded with Arcana + materials.
  Skills are equipped into hotbar slots (5 by default, purchasable up to 9)
  and toggled **Shift + Right Click** — fully mobile/Bedrock-Geyser friendly,
  no keyboard-only controls.
- **7 Magic Items** (Windcaller, Guardian Shield, Phoenix Feather, Lifebloom,
  Stormcore, Moonstone, Thorncore), each with 3 levels, equipped/unequipped
  entirely through the GUI (3 slots by default, purchasable up to 7).
- **Custom Xsibion Crafting**: a protected 3×3 chest GUI with a live recipe
  preview, Arcana cost display, and full anti-duplication/anti-theft
  protection. Does not touch vanilla crafting.
- Everything (rewards, costs, cooldowns, effect magnitudes, slot limits,
  recipes, messages, GUI titles) is configurable in `config.yml`.

## Requirements

- A Paper (or Paper-fork) server running **Minecraft 1.20.4**.
- Java 17 or newer on the server.

## Building

This repository builds automatically via GitHub Actions on every push
(`.github/workflows/build.yml`) — just push it to GitHub and download the
`Xsibion-plugin` artifact from the Actions tab, no local machine required.

To build locally instead:

```bash
mvn clean package
```

The compiled plugin will be at `target/Xsibion-1.0.0.jar`.

## Installation

1. Drop `Xsibion-1.0.0.jar` into your Paper server's `plugins/` folder.
2. Start (or restart) the server. A default `config.yml` will be generated
   under `plugins/Xsibion/config.yml`.
3. Edit `plugins/Xsibion/config.yml` to taste (rewards, costs, recipes,
   messages, etc.) and run `/xsibion reload` (requires OP) to apply changes
   without a restart.
4. Players can now run `/xsibion` to open the main menu.

## Commands

| Command | Description | Permission |
|---|---|---|
| `/xsibion` | Opens the Xsibion main menu (Skills / Magic Items / Crafting / Arcana). | none |
| `/xsibion reload` | Reloads `config.yml` (definitions, recipes, messages). Player data is untouched. | OP only |

## Notes on Bedrock / Geyser support

Every interaction in Xsibion uses only Hotbar selection + Right Click +
Shift, plus GUI clicks — nothing relies on the Q key, number-row hotkeys, or
any other keyboard-only input, so it works identically for Java Edition
players and Bedrock players connecting through Geyser. Custom item textures
can be layered on top with Java/Bedrock resource packs; the plugin tags every
Skill item with a stable PersistentDataContainer key so resource packs (or
CustomModelData you add yourself) can target them reliably.
